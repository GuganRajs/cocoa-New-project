import React, { useEffect, useState, useRef } from 'react';
import {
	StyleSheet,
	Text,
	View,
	FlatList,
	TouchableOpacity,
	Image,
	ActivityIndicator,
	Modal,
	TouchableWithoutFeedback,
	Alert,
	Animated,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

const FarmersData = () => {
	const navigation = useNavigation();

	const [form3Farmers, setForm3Farmers] = useState([]);
	const [form7Farmers, setForm7Farmers] = useState([]);
	const [loading, setLoading] = useState(true);
	const [activeTab, setActiveTab] = useState('Form 3');
	const [selectedFarmer, setSelectedFarmer] = useState(null);
	const [modalVisible, setModalVisible] = useState(false);
	const [currentPage, setCurrentPage] = useState(1); // For pagination
	const [isFetchingMore, setIsFetchingMore] = useState(false);

	// Persistent animation value
	const tabAnimation = useRef(new Animated.Value(0)).current;

	useEffect(() => {
		fetchFarmersData(activeTab, currentPage);
	}, [activeTab, currentPage]);

	const fetchFarmersData = async (tab, page) => {
		try {
			if (page === 1) setLoading(true);
			const token = await AsyncStorage.getItem('access_token');
			const apiUrl =
				tab === 'Form 3'
					? `http://159.13.36.60:8000/api/farmers/?skip=${(page - 1) * 10}&limit=10&search=`
					: `http://159.13.36.60:8000/api/farmergroups/?skip=${(page - 1) * 10}&limit=10&search=`;

			const response = await axios.get(apiUrl, {
				headers: {
					Authorization: `Bearer ${token}`,
				},
			});

			const transformedData = response.data.result.map((item, index) => ({
				id: item.id,
				name:
					tab === 'Form 3'
						? `${item.farmer_first_name} ${item.farmer_last_name}`.trim()
						: item.farmer_group_name || 'N/A',
				phone: tab === 'Form 3' ? item.phone || 'N/A' : 'N/A',
				district: item.province?.province_name || 'N/A',
				photo: item.photo || null,
				autoId: `${(index + 1 + (page - 1) * 10).toString().padStart(2, '0')}`, // Auto-increment ID with pagination
			}));

			if (tab === 'Form 3') {
				setForm3Farmers(page === 1 ? transformedData : [...form3Farmers, ...transformedData]);
			} else {
				setForm7Farmers(page === 1 ? transformedData : [...form7Farmers, ...transformedData]);
			}
			setLoading(false);
			setIsFetchingMore(false);
		} catch (error) {
			console.error('Error fetching farmers data:', error);
			setLoading(false);
			setIsFetchingMore(false);
		}
	};

	const handleLoadMore = () => {
		setIsFetchingMore(true);
		setCurrentPage((prevPage) => prevPage + 1);
	};

	const renderFarmerItem = ({ item }) => {
		const imageUrl = item.photo
			? `http://159.13.36.60:8000/uploads/farmers/${item.photo}`
			: 'https://via.placeholder.com/40';

		return (
			<View style={styles.tableRow}>
				<View style={styles.applicationId}>
					<Image source={{ uri: imageUrl }} style={styles.avatar} />
					<Text style={styles.autoId}>{item.autoId}</Text>
				</View>
				<View style={styles.farmerDetails}>
					<Text style={styles.farmerName}>{item.name}</Text>
				</View>
				<View style={styles.menuContainer}>
					<TouchableOpacity onPress={() => handleMenuPress(item)}>
						<Image
							source={require('../assets/menu.png')}
							style={styles.menuImage}
						/>
					</TouchableOpacity>
				</View>
			</View>
		);
	};

	const handleMenuPress = (farmer) => {
		setSelectedFarmer(farmer);
		setModalVisible(true);
	};

	const handleEdit = () => {
		Alert.alert('Edit Farmer', `Editing ${selectedFarmer.name}`);
		setModalVisible(false);
	};

	const handleDelete = () => {
		Alert.alert('Delete Farmer', `Are you sure you want to delete ${selectedFarmer.name}?`, [
			{
				text: 'Cancel',
				onPress: () => setModalVisible(false),
			},
			{
				text: 'OK',
				onPress: () => {
					if (activeTab === 'Form 3') {
						setForm3Farmers(form3Farmers.filter((farmer) => farmer.id !== selectedFarmer.id));
					} else {
						setForm7Farmers(form7Farmers.filter((farmer) => farmer.id !== selectedFarmer.id));
					}
					setModalVisible(false);
				},
			},
		]);
	};

	const handleTabSwitch = (tab) => {
		Animated.timing(tabAnimation, {
			toValue: tab === 'Form 3' ? 0 : 1,
			duration: 300,
			useNativeDriver: true,
		}).start(() => {
			setActiveTab(tab);
			setCurrentPage(1); // Reset pagination on tab switch
		});
	};

	const farmersList = activeTab === 'Form 3' ? form3Farmers : form7Farmers;

	if (loading && !isFetchingMore) {
		return (
			<View style={styles.loadingContainer}>
				<ActivityIndicator size="large" color="#4F2E1D" />
			</View>
		);
	}

	return (
		<View style={styles.container}>
			<Text style={styles.header}>Farmer Data</Text>

			{/* Tabs */}
			<View style={styles.tabs}>
				<Animated.View
					style={[
						styles.tabHighlight,
						{
							transform: [
								{
									translateX: tabAnimation.interpolate({
										inputRange: [0, 1],
										outputRange: [0, 150], // Adjust for tab width
									}),
								},
							],
						},
					]}
				/>
				<TouchableOpacity
					style={[styles.tab, activeTab === 'Form 3' && styles.activeTab]}
					onPress={() => handleTabSwitch('Form 3')}
				>
					<Text style={[styles.tabText, activeTab === 'Form 3' && styles.activeTabText]}>
						Form 3
					</Text>
				</TouchableOpacity>
				<TouchableOpacity
					style={[styles.tab, activeTab === 'Form 7' && styles.activeTab]}
					onPress={() => handleTabSwitch('Form 7')}
				>
					<Text style={[styles.tabText, activeTab === 'Form 7' && styles.activeTabText]}>
						Form 7
					</Text>
				</TouchableOpacity>
			</View>

			{/* Create Button */}
			<TouchableOpacity
				onPress={() => navigation.navigate(activeTab === 'Form 3' ? 'form3PartA' : 'form7')}
				style={styles.createButton}
			>
				<View style={styles.createButtonContent}>
					<Image
						source={require('../assets/plus.png')}
						style={styles.plusIcon}
					/>
					<Text style={styles.createButtonText}>
						{activeTab === 'Form 3'
							? 'Create Farmer Baseline Questionnaire - Form 3'
							: 'Create Cocoa Farmer Group and Cooperative Profile - Form 7'}
					</Text>
				</View>
			</TouchableOpacity>

			{/* Table Header */}
			<View style={styles.tableHeader}>
				<Text style={styles.tableHeaderText}>Application #</Text>
				<Text style={styles.tableHeaderText}>Name</Text>
			</View>

			{/* Farmers List */}
			<FlatList
				data={farmersList}
				keyExtractor={(item) => item.id.toString()}
				renderItem={renderFarmerItem}
				contentContainerStyle={styles.list}
				onEndReached={handleLoadMore}
				onEndReachedThreshold={0.5}
				ListFooterComponent={
					isFetchingMore && (
						<ActivityIndicator size="small" color="#4F2E1D" style={{ marginVertical: 10 }} />
					)
				}
			/>

			{/* Modal for Edit and Delete */}
			<Modal
				transparent={true}
				animationType="fade"
				visible={modalVisible}
				onRequestClose={() => setModalVisible(false)}
			>
				<TouchableWithoutFeedback onPress={() => setModalVisible(false)}>
					<View style={styles.modalOverlay}>
						<View style={styles.modalContainer}>
							<Text style={styles.modalTitle}>Options</Text>
							<TouchableOpacity onPress={handleEdit}>
								<Text style={styles.modalOption}>Edit</Text>
							</TouchableOpacity>
							<TouchableOpacity onPress={handleDelete}>
								<Text style={styles.modalOption}>Delete</Text>
							</TouchableOpacity>
						</View>
					</View>
				</TouchableWithoutFeedback>
			</Modal>
		</View>
	);
};

export default FarmersData;

const styles = StyleSheet.create({
	container: { flex: 1, backgroundColor: '#fff' },
	header: { fontSize: 20, fontWeight: 'bold', marginVertical: 10, textAlign: 'center' },
	tabs: { flexDirection: 'row', justifyContent: 'center', position: 'relative' },
	tab: { flex: 1, paddingVertical: 10, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: '#ccc' },
	activeTab: { borderBottomColor: '#4F2E1D' },
	tabText: { fontSize: 16, fontWeight: 'bold', color: '#888' },
	activeTabText: { color: '#4F2E1D' },
	tabHighlight: {
		position: 'absolute',
		width: '50%',
		height: 4,
		backgroundColor: '#4F2E1D',
		bottom: 0,
		left: 0,
	},
	createButton: { backgroundColor: '#4F2E1D', padding: 10, margin: 10, borderRadius: 5 },
	createButtonContent: { flexDirection: 'row', alignItems: 'center' },
	plusIcon: { width: 20, height: 20, marginRight: 10 },
	createButtonText: { color: '#fff', fontSize: 16 },
	tableHeader: { flexDirection: 'row', justifyContent: 'space-between', padding: 10, backgroundColor: '#eee' },
	tableHeaderText: { fontWeight: 'bold', fontSize: 14 },
	avatar: { width: 40, height: 40, borderRadius: 20 },
	autoId: { fontSize: 14, marginLeft: 10 },
	farmerDetails: { flex: 1, justifyContent: 'center', marginHorizontal: 10 },
	farmerName: { fontSize: 14, fontWeight: 'bold' },
	menuContainer: { justifyContent: 'center', alignItems: 'center', width: 50 },
	menuImage: { width: 20, height: 20 },
	modalOverlay: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.5)' },
	modalContainer: { backgroundColor: '#fff', padding: 20, borderRadius: 5, width: 300 },
	modalTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 10 },
	modalOption: { fontSize: 16, marginVertical: 5, color: '#4F2E1D' },
	loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
	container: {
		flex: 1,
		backgroundColor: '#fff',
		// padding: 20,
	},
	header: {
		fontSize: 28,
		fontWeight: 'normal',
		color: '#9D562B',
		padding: 10,
	},
	tabs: {
		flexDirection: 'row',
		marginBottom: 15,
	},
	tab: {
		flex: 1,
		paddingVertical: 10,
		borderBottomWidth: 2,
		borderBottomColor: '#eee',
		alignItems: 'center',
	},
	activeTab: {
		borderBottomColor: '#4F2E1D',
		backgroundColor: '#A2DFCF',
		borderTopRightRadius: 20,
		borderTopLeftRadius: 20,
	},
	tabText: {
		fontSize: 16,
		color: '#999',
	},
	activeTabText: {
		color: '#4F2E1D',
		fontWeight: 'bold',
	},
	createButton: {
		padding: 10,
		// marginBottom: 20,
		borderRadius: 8,
		alignItems: 'center',
	},
	createButtonContent: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	plusIcon: {
		width: 20,
		height: 20,
		marginRight: 10,
	},
	createButtonText: {
		color: '#4F2E1D',
		fontWeight: 'bold',
		fontSize: 16,
		paddingHorizontal:15,
	},
	tableHeader: {
		flexDirection: 'row',
		alignItems: 'center',
		backgroundColor: '#F3F3F3',
		paddingVertical: 20,
		paddingHorizontal: 20,
		borderRadius: 8,
	},
	tableHeaderText: {
		flex: 1,
		fontSize: 14,
		fontWeight: 'bold',
		color: '#555',
	},
	tableName: {
		flex: 2,
	},
	list: {
		marginTop: 10,
	},
	tableRow: {
		flexDirection: 'row',
		alignItems: 'center',
		backgroundColor: '#fff',
		paddingVertical: 10,
		paddingHorizontal: 15,
		borderBottomWidth: 1,
		borderBottomColor: '#eee',
	},
	applicationId: {
		flex: 1,
		flexDirection: 'row',
		// paddingLeft: 60,
	},
	farmerDetails: {
		flex: 1,
		// paddingLeft: 60,
	},
	farmerName: {
		fontSize: 16,
		fontWeight: 'bold',
		color: '#555',
	},
	farmerPhone: {
		fontSize: 14,
		color: '#777',
	},
	avatar: {
		width: 40,
		height: 40,
		borderRadius: 20, // Makes the image circular
		marginRight: 10, // Space between photo and name
	},
	menuContainer: {
		justifyContent: 'center',
		alignItems: 'center',
		flexDirection: 'row', // Horizontal menu
		paddingLeft: 10,
	},
	menuText: {
		fontSize: 20,
		color: '#4F2E1D',
	},
	loadingContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
	},
	modalOverlay: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: 'rgba(0, 0, 0, 0.5)',
	},
	modalContent: {
		backgroundColor: '#fff',
		padding: 20,
		borderRadius: 8,
		width: '80%',
	},
	modalText: {
		fontSize: 18,
		fontWeight: 'bold',
		marginBottom: 15,
	},
	modalOption: {
		fontSize: 16,
		color: '#4F2E1D',
		marginBottom: 10,
	},
	menuImage:{
		height: 20,
		width: 20,
	},
	autoId: {
		fontSize: 14,
		fontWeight: 'bold',
		color: '#333', // Darker shade for distinction
		marginBottom: 4, // Space between Auto ID and Name
	},

});
