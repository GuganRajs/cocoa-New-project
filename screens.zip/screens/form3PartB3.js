import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
  ScrollView,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Picker} from '@react-native-picker/picker';
import {useNavigation} from '@react-navigation/native';
import axios from 'axios';
import DatePickers from '../components/utils/DatePickers';
import AsyncStorage from '@react-native-async-storage/async-storage';

const FarmerForm4 = ({route}) => {
  const {responseData} = route.params;

  console.log(responseData);
  const navigation = useNavigation();
  const [formData, setFormData] = useState({
    title: 'Mr',
    firstName: '',
    lastName: '',
    age: '0',
    gender: 'Male',
    mobileNumber: '',
    region: '',
    province: '',
    photo: null,
    last_tech_officer_visited: '',
    officer_come: '',
    training_do_you_lack: '', // Add this key
    other_comments: '', // Add this key
	officer_organisation: '',
  });
  const [selectedTitle, setSelectedTitle] = useState();
  const [isFocused, setIsFocused] = useState(false);
  const [selectedValue, setSelectedValue] = useState(null);
  const [modeOfTransport, setModeOfTransport] = useState('');
  const [text, setText] = useState('');
  const [plotData, setPlotData] = useState([1]); // Array to manage plot details
  const [plotDates, setPlotDates] = useState([]);

  const transportOptions = [
    {label: 'Land', value: 'Land'},
    {label: 'Sea', value: 'Sea'},
    {label: 'Air', value: 'Air'},
  ];

  const plotOptions = [
    {label: 'Yes', value: 'Yes'},
    {label: 'No', value: 'No'},
  ];

  const sellingBagOptions = [
    {label: 'Individual sales', value: 'Individual sales'},
    {label: 'Group marketing', value: 'Group marketing'},
    {label: 'Direct Export', value: 'Direct Export'},
  ];

  const updatePlotDate = (index, dateObj) => {
    if (!dateObj || !dateObj.value) {
      console.error('Invalid date object:', dateObj);
      return;
    }

    try {
      const isoDate = new Date(dateObj.value).toISOString(); // Access the `value` property
      const updatedDates = [...plotDates];
      updatedDates[index] = isoDate;
      setPlotDates(updatedDates);
    } catch (error) {
      console.error('Error parsing date:', dateObj, error);
    }
  };

  //   API Started

  const updateFarmerDataB3 = async () => {
    try {
      // Fetch token and farmerId from AsyncStorage
      const token = await AsyncStorage.getItem('access_token');
      const farmerId = await AsyncStorage.getItem('farmerId');

      console.log('Farmer ID:', farmerId);

      // Check if token or farmerId is missing
      if (!token || !farmerId) {
        Alert.alert('Error', 'Missing token or farmer ID.');
        return;
      }

      // Your API URL
      const apiUrl = `http://159.13.36.60:8000/api/farmers/${farmerId}`;

      // Prepare the payload for the API request
      const payload = {
        title: responseData.title,
        farmer_first_name: responseData.farmer_first_name,
        farmer_last_name: responseData.farmer_last_name,
        gender: responseData.gender,
        age: responseData.age,
        phone: responseData.phone,
        region_id: responseData.region_id,
        province_id: responseData.province_id,
        district_id: responseData.district_id,
        llg_id: responseData.llg_id,
        ward_id: responseData.ward_id,
        marital_status: responseData.marital_status,
        no_of_children: responseData.no_of_children,
        edu_qualification: responseData.edu_qualification,
        is_bank_account: responseData.s_bank_account,
        bank_name: responseData.bank_name,
        bank_branch: responseData.bank_branch,
        is_records_of_cocoa_sales: responseData.is_records_of_cocoa_sales,
        what_type_of_records: formData.rec_do_you_have,
        no_of_cocoa_plots: responseData.no_of_cocoa_plots,
        no_of_cocoa_plots_planted: responseData.no_of_cocoa_plots_planted,
        name_of_plots: responseData.name_of_plots,
        no_of_trees: responseData.no_of_trees,
        total_no_of_trees: responseData.total_no_of_trees, // Calculate total trees
        planted_year: responseData.planted_year,
        planting_material: responseData.planting_material,
        variety_of_cocoa: responseData.variety_of_cocoa,
        is_replanting_plan: responseData.is_replanting_plan,
        replanting_variety: responseData.replanting_variety,
        is_cocoa_certification: false,
        certification_program: responseData.certification_program,
        cocoa_fermentary_details: responseData.cocoa_fermentary_details,
        fermentary_id: '',
        fermentary_code: responseData.fermentary,
        fermentary_number: '',
        is_fermentary_register: false,
        fermentary_register_date: responseData.fermentaryRegisterDate,
        wetbean_produce_year_kgs: formData.wetbean_produce_year_kgs,
        is_sell_wetbean: formData.is_sell_wetbean,
        wetbean_sell_year_kgs: formData.wetbean_sell_year_kgs,
        wetbean_avg_price: formData.wetbean_avg_price,
        wetbean_total_earned: formData.wetbean_total_earned,
        drybean_bag_sell_last_year: formData.drybean_bag_sell_last_year,
        drybean_sell_to: formData.drybean_bag_sell_last_year,
        drybean_earned_last_year: formData.drybean_earned_last_year,
        drybean_avg_price: formData.drybean_avg_price,
        drybean_bag_transport_cost: formData.drybean_bag_transport_cost,
        drybean_how_you_sell: formData.drybean_sell_to,
        is_member_of_farmer_group: false,
        farmergroups_id: '',
        farmer_group_name: formData.farmer_group_name,
        cocoa_farming_system: '',
        form_of_income_source: [],
        name_of_the_echo_business: '',
        mode_of_transport: modeOfTransport,
        cost_of_transport: formData.kinaValue,
        is_cocoa_tool: false,
        cocoa_tool_details: [
          {
            tool: '',
            quantity: '',
            condition: '',
            supplier: '',
          },
        ],
        last_tech_officer_visited: formData.plotDates,
        officer_organisation: formData.officer_organisation,
        training_do_you_lack: formData.training_do_you_lack,
        other_comments: formData.other_comments,
        training_details: [
          {
            training: '',
            date: '',
            location: '',
            organisation: '',
          },
        ],
        fermentary: {
          fermentary_code: responseData.fermentryDryer,
          fermentary_delear_no: responseData.fermentryDryer,
        },
        interviewer_title: 'Mr',
        interviewer_first_name: '',
        interviewer_last_name: '',
        interviewer_gender: '',
        interviewer_designation: '',
        interviewer_division_id: '',
        interviewer_project_id: '',
        interviewer_branch_id: '',
        enumaration_title: 'Mr',
        enumaration_first_name: '',
        enumaration_last_name: '',
        enumaration_gender: '',
        enumaration_designation: '',
        enumaration_branch_id: '',
      };

      // Log the payload for debugging
      console.log('Submitting form data:', JSON.stringify(payload, null, 2));

      // Make the API PUT request to submit the data
      const response = await axios.put(apiUrl, payload, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      // Log the successful response
      console.log('Form data submitted successfully:', response.data);

      // Show success alert
      alert('Form 3 data submitted successfully!');
      navigation.navigate('form3PartC', {
        responseData: response.data, // Pass the API response as a param
        // Add any other necessary fields here
      });
    } catch (error) {
      // Log the error details for debugging
      console.error('Error submitting form data:', error);

      // If error response exists, log the response data and status code
      if (error.response) {
        console.error('Error response data:', error);
        console.error('Error response status:', error.response.status);
      }

      // Show error message from server or a generic message
      const errorMessage =
        error.response?.data?.message ||
        'Failed to submit form data. Please try again.';

      // Display the error message in an alert
      Alert.alert('Error', errorMessage);
    }
  };

  //  API Completed
  return (
    <View style={styles.container}>
      {/* Header */}
      <Text style={styles.header}>
        <Text style={{color: '#8a4e28'}}>Form 3 : </Text>Farmer Baseline
        Questionnaire
      </Text>

      <View style={styles.containerTab}>
        {/* Step A */}
        <View style={styles.tabContainer}>
          <TouchableOpacity style={[styles.circle, styles.completeCircle]}>
            <Icon name="check" size={12} color="#ccc" />
          </TouchableOpacity>
          <Text style={[styles.tabText, styles.activeText]}>Part A</Text>
        </View>

        {/* Divider */}
        <View style={styles.line} />

        {/* Part B */}
        <View style={styles.tabContainer}>
          <TouchableOpacity style={[styles.circle, styles.activeCircle]}>
            <Icon name="check" size={12} color="#ccc" />
          </TouchableOpacity>
          <Text style={styles.tabText}>Part B</Text>

          <Text style={styles.tabText}>3/3</Text>
        </View>

        {/* Divider */}
        <View style={styles.line} />

        {/* Part C */}
        <View style={styles.tabContainer}>
          <TouchableOpacity style={styles.circle}>
            <Icon name="check" size={12} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.tabText}>Part C</Text>
        </View>
      </View>

      <ScrollView style={{marginBottom: 6}}>
        {/* fermentary & dryer */}
        <Text style={styles.sectionTitle}>Part B: Cocoa transport details</Text>
        <Text style={styles.subtitle}>Enter Cocoa transport details here</Text>

        <Text style={([styles.heading], {marginBottom: 10})}>
          Which mode of transport do you use to your nearest economical or
          business hub?
        </Text>

        <View style={styles.field}>
          {transportOptions.map(option => (
            <TouchableOpacity
              key={option.value}
              style={styles.radioContainer}
              onPress={() => setModeOfTransport(option.value)}>
              <View style={styles.radioCircle}>
                {modeOfTransport === option.value && (
                  <View style={styles.selectedCircle} />
                )}
              </View>
              <Text style={styles.radioText}>{option.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={styles.label1}>
            What is the cost of using the transport in kina value? Estimate
            amount or fix amount from farm or village to nearest economical or
            business hub (PGK)
          </Text>
          <Text></Text>
          <Text></Text>
          <TextInput
            style={styles.input}
            placeholder="Enter kina value"
            value={formData.kinaValue}
            keyboardType="numeric" // Restrict input to numbers
            onChangeText={text => {
              const numericValue = text.replace(/[^0-9]/g, ''); // Allow only numeric input
              setFormData({...formData, kinaValue: numericValue});
            }}
          />
        </View>

        {/* tools details */}
        <Text style={styles.sectionTitle}>Part B: Cocoa tools details</Text>
        <Text style={styles.subtitle}>Enter Cocoa tools details here</Text>

        <Text style={([styles.heading], {marginBottom: 10})}>
          Do you have cocoa tools, equipment & chemicals?
        </Text>

        <View style={[styles.radioGroup]}>
          {plotOptions.map(option => (
            <TouchableOpacity
              key={option.value}
              style={styles.radioContainer}
              onPress={() => setSelectedValue(option.value)}>
              <View style={styles.radioCircle}>
                {selectedValue === option.value && (
                  <View style={styles.selectedCircle} />
                )}
              </View>
              <Text style={styles.radioText}>{option.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Training Details */}
        <Text style={styles.sectionTitle}>
          Part B: Cocoa Farmer Training Details
        </Text>
        <Text style={styles.subtitle}>
          Enter Cocoa farmer training details here
        </Text>

        {plotData.map((plot, index) => (
          <View key={index} style={styles.containerInput}>
            <Text style={styles.label1}>
              When was the last time a technical cocoa officer visited you?
            </Text>
            <DatePickers
              label=""
              value={plotDates[index] || ''} // Pre-fill with selected date
              onChange={dateObj => {
                console.log('Selected date object:', dateObj);
                updatePlotDate(index, dateObj); // Correctly update plot date
              }}
              placeholder="DD-MM-YYYY"
            />
          </View>
        ))}

        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={styles.label1}>
            From which organisation did the officer come from?
          </Text>
          <TextInput
            style={styles.input}
            placeholder="Enter here"
            value={formData.officer_organisation}
            onChangeText={text =>
              setFormData({...formData, officer_organisation: text})
            }
          />
        </View>

        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={styles.label1}>
            What sort of training do you lack and would like to be trained on to
            improve your cocoa work?
          </Text>
          <TextInput
            style={styles.input}
            placeholder="Enter here"
            value={formData.training_do_you_lack}
            onChangeText={text =>
              setFormData({...formData, training_do_you_lack: text})
            }
          />
        </View>

        <View>
          <TextInput
            style={styles.textArea}
            value={formData.other_comments}
            onChangeText={text =>
              setFormData({...formData, other_comments: text})
            }
            placeholder="If you have any other comments?"
            placeholderTextColor="#888"
            multiline={true} // Enables multi-line input
            numberOfLines={4} // Initial number of lines to display
          />
        </View>
      </ScrollView>

      <TouchableOpacity
        onPress={() => updateFarmerDataB3(formData, navigation)}
        style={styles.savebtn}>
        <Text style={styles.savebtnText}>
          Save and Continue <Icon name="arrow-right" size={12} />
        </Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  containerTab: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    backgroundColor: '#f7efe7',
    marginBottom: 10,
  },
  tabContainer: {
    alignItems: 'center',
    flexDirection: 'column',
  },
  circle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#ccc',
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeCircle: {
    backgroundColor: '#8a4e28', // Matches the active color in the example
  },

  completeCircle: {
    backgroundColor: '#02A552',
  },
  tabText: {
    marginTop: 4,
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  activeText: {
    color: '#000', // Active text color
    fontWeight: 'bold',
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: '#ccc',
    marginHorizontal: 8,
    marginTop: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    color: '#8a4e28',
  },
  subtitle: {
    fontSize: 12,
    color: '#666',
    marginBottom: 16,
    color: '#2F7F6A',
  },
  field: {
    marginBottom: 16,
  },
  inputRow: {
    marginVertical: 15,
    flexDirection: 'row',
  },
  input: {
    borderRadius: 5,
    backgroundColor: '#F7F7F7',
  },
  picker: {
    fontSize: 10,
    height: 40,
    backgroundColor: '#F7F7F7',
  },
  pickItem: {
    fontSize: 14,
  },
  containerInput: {
    position: 'relative',
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginVertical: 10,
  },
  label: {
    position: 'absolute',
    top: -10,
    left: 10,
    backgroundColor: '#fff',
    paddingHorizontal: 5,
    fontSize: 12,
    color: '#ccc',
  },
  label1: {
    position: 'absolute',
    top: -15,
    left: 10,
    backgroundColor: '#fff',
    paddingHorizontal: 5,
    fontSize: 12,
    color: '#949494',
  },

  label: {
    position: 'absolute',
    top: -10,
    left: 10,
    backgroundColor: '#fff',
    paddingHorizontal: 5,
    fontSize: 12,
    color: '#949494',
  },
  focusedLabel: {
    color: '#000',
  },
  heading: {
    fontSize: 14,
    fontWeight: 'bold',
    marginRight: 10,
  },
  radioContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: 10,
  },
  radioCircle: {
    height: 15,
    width: 15,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#ccc',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 5,
  },
  selectedCircle: {
    height: 10,
    width: 10,
    borderRadius: 5,
    backgroundColor: '#ccc',
  },
  radioText: {
    fontSize: 12,
    color: '#333',
  },
  ageInput: {
    flex: 1,
    marginRight: 8,
  },
  radioGroup: {
    flexDirection: 'row',
    flex: 1,
  },
  selectedGender: {
    backgroundColor: '#8a4e28',
    color: '#fff',
  },
  uploadButton: {
    flex: 2,
    padding: 8,
    backgroundColor: '#F2F2F2',
    borderRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
  },
  photoPreview: {
    width: 40,
    height: 40,
    marginTop: 8,
    borderRadius: 20,
  },
  savebtn: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 300,
    height: 50,
    marginHorizontal: 25,
    backgroundColor: '#ecded5',
    borderRadius: 10,
  },
  savebtnText: {
    fontSize: 18,
    color: '#9d562b',
  },

  textArea: {
    width: '100%',
    height: 70,
    borderRadius: 8,
    padding: 10,
    textAlignVertical: 'top',
    backgroundColor: '#F7F7F7',
  },
});

export default FarmerForm4;
