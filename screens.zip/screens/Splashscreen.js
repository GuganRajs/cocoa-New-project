/* eslint-disable prettier/prettier */
import React, {Component} from 'react';
import {
  View,
  Text,
  ImageBackground,
  StyleSheet,
  Dimensions
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {connect} from 'react-redux';
import {loggedIn} from '../redux/reducer';

const {width, height} = Dimensions.get('window'); // Get screen dimensions

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%', // Ensures the image covers the width
    height: '100%', // Ensures the image covers the height
  },
  textContainer: {
    marginTop: height * 0.2, // Dynamic margin based on screen height
  },
  welcomeText: {
    fontSize: width * 0.1, // Font size proportional to screen width
    color: '#2f855a',
    marginBottom: 5,
    fontFamily: 'Wittgenstein',
  },
  title: {
    fontSize: width * 0.09, // Font size proportional to screen width
    textAlign: 'left',
    color: 'black',
  },
  mainContainer: {
    marginTop: height * 0.1, // Dynamic margin based on screen height
    width: '60%', // Responsive width
  },
});

class SplashScreen extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this._bootstrapAsync();
  }

  _bootstrapAsync = async () => {
    const userToken = await AsyncStorage.getItem('loginData');
    setTimeout(() => {
      this.props.loggedIn(JSON.parse(userToken));
    }, 5000);
  };


  render() {
    return (
      <ImageBackground
        source={require('../assets/splashScreen.jpeg')}
        style={styles.container}
        resizeMode="cover"
      >
        <View style={styles.textContainer}>
          <View style={styles.mainContainer}>
            <Text style={styles.welcomeText}>
              Welcome<Text style={styles.title}> to</Text>
            </Text>
            <Text style={styles.title}>Cocoa Management Information System</Text>
          </View>
        </View>
      </ImageBackground>
    ); 
  }
}

const mapStateToProps = state => ({
  // loginDetails: state.loginDetails
});

export default connect(mapStateToProps, {loggedIn})(SplashScreen);


9498794987