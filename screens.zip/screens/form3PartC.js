import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
  ScrollView,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Picker} from '@react-native-picker/picker';
import {useNavigation} from '@react-navigation/native';
import axios from 'axios';
import DatePickers from '../components/utils/DatePickers';
import AsyncStorage from '@react-native-async-storage/async-storage';

const FarmerForm5 = ({route}) => {
  const {responseData} = route.params;

  const navigation = useNavigation();
  const [formData, setFormData] = useState({
    title: 'Mr',
    firstName: '',
    lastName: '',
    age: '0',
    gender: 'Male',
    mobileNumber: '',
    region: '',
    province: '',
	interviewer_first_name: '',
	interviewer_last_name: '',
	division: '',
	project: '',
	office_location: '',
	organisation:'',
    photo: null,
  });
  const [selectedTitle, setSelectedTitle] = useState();
  const [isFocused, setIsFocused] = useState(false);
  const [selectedValue, setSelectedValue] = useState(null);
  const [SelectedDesig, setSelectedDesig] = useState(null);
  const [selectedValueDesigEnu, setSelectedValueDes] = useState(null);
  const [selectedValueEnuGender, setSelectedValueEnuGender] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [text, setText] = useState('');

  const genderOptions = [
    {label: 'Male', value: 'male'},
    {label: 'Female', value: 'female'},
    {label: 'Other', value: 'other'},
  ];

  const designationOptions = [
    {label: 'Officer', value: 'Officer'},
    {label: 'Researcher', value: 'Researcher'},
  ];

  const sellingBagOptions = [
    {label: 'Individual sales', value: 'Individual sales'},
    {label: 'Group marketing', value: 'Group marketing'},
    {label: 'Direct Export', value: 'Direct Export'},
  ];

  //   API Started

  const updateFarmerDataB3 = async () => {
    try {
      // Fetch token and farmerId from AsyncStorage
      const token = await AsyncStorage.getItem('access_token');
      const farmerId = await AsyncStorage.getItem('farmerId');

      console.log('Farmer ID:', farmerId);

      // Check if token or farmerId is missing
      if (!token || !farmerId) {
        Alert.alert('Error', 'Missing token or farmer ID.');
        return;
      }

      // Your API URL
      const apiUrl = `http://159.13.36.60:8000/api/farmers/${farmerId}`;

      // Prepare the payload for the API request
      const payload = {
        title: responseData.title,
        farmer_first_name: responseData.farmer_first_name,
        farmer_last_name: responseData.farmer_last_name,
        gender: responseData.gender,
        age: responseData.age,
        phone: responseData.phone,
        region_id: responseData.region_id,
        province_id: responseData.province_id,
        district_id: responseData.district_id,
        llg_id: responseData.llg_id,
        ward_id: responseData.ward_id,
        marital_status: responseData.marital_status,
        no_of_children: responseData.no_of_children,
        edu_qualification: responseData.edu_qualification,
        is_bank_account: responseData.s_bank_account,
        bank_name: responseData.bank_name,
        bank_branch: responseData.bank_branch,
        is_records_of_cocoa_sales: responseData.is_records_of_cocoa_sales,
        what_type_of_records: formData.rec_do_you_have,
        no_of_cocoa_plots: responseData.no_of_cocoa_plots,
        no_of_cocoa_plots_planted: responseData.no_of_cocoa_plots_planted,
        name_of_plots: responseData.name_of_plots,
        no_of_trees: responseData.no_of_trees,
        total_no_of_trees: responseData.total_no_of_trees, // Calculate total trees
        planted_year: responseData.planted_year,
        planting_material: responseData.planting_material,
        variety_of_cocoa: responseData.variety_of_cocoa,
        is_replanting_plan: responseData.is_replanting_plan,
        replanting_variety: responseData.replanting_variety,
        is_cocoa_certification: false,
        certification_program: responseData.certification_program,
        cocoa_fermentary_details: responseData.cocoa_fermentary_details,
        fermentary_id: '',
        fermentary_code: responseData.fermentary,
        fermentary_number: '',
        is_fermentary_register: false,
        fermentary_register_date: responseData.fermentaryRegisterDate,
        wetbean_produce_year_kgs: responseData.wetbean_produce_year_kgs,
        is_sell_wetbean: responseData.is_sell_wetbean,
        wetbean_sell_year_kgs: responseData.wetbean_sell_year_kgs,
        wetbean_avg_price: responseData.wetbean_avg_price,
        wetbean_total_earned: responseData.wetbean_total_earned,
        drybean_bag_sell_last_year: responseData.drybean_bag_sell_last_year,
        drybean_sell_to: responseData.drybean_bag_sell_last_year,
        drybean_earned_last_year: responseData.drybean_earned_last_year,
        drybean_avg_price: responseData.drybean_avg_price,
        drybean_bag_transport_cost: responseData.drybean_bag_transport_cost,
        drybean_how_you_sell: responseData.drybean_sell_to,
        is_member_of_farmer_group: false,
        farmergroups_id: '',
        farmer_group_name: responseData.farmer_group_name,
        cocoa_farming_system: '',
        form_of_income_source: [],
        name_of_the_echo_business: '',
        mode_of_transport: responseData.modeOfTransport,
        cost_of_transport: responseData.kinaValue,
        is_cocoa_tool: false,
        cocoa_tool_details: [
          {
            tool: '',
            quantity: '',
            condition: '',
            supplier: '',
          },
        ],
        last_tech_officer_visited: responseData.plotDates,
        officer_organisation: responseData.officer_organisation,
        training_do_you_lack: responseData.training_do_you_lack,
        other_comments: responseData.other_comments,
        training_details: [
          {
            training: '',
            date: '',
            location: '',
            organisation: '',
          },
        ],
        fermentary: {
          fermentary_code: responseData.fermentryDryer,
          fermentary_delear_no: responseData.fermentryDryer,
        },
        interviewer_title: 'Mr',
        interviewer_first_name: formData.interviewer_first_name,
        interviewer_last_name: formData.interviewer_last_name,
        interviewer_gender: selectedValue,
        interviewer_designation: SelectedDesig,
        interviewer_division_id: formData.division,
        interviewer_project_id: formData.project,
        interviewer_branch_id: formData.office_location,
        enumaration_title: 'Mr',
        enumaration_first_name: formData.enu_first_name,
        enumaration_last_name: formData.enu_last_name,
        enumaration_gender: selectedValueEnuGender,
        enumaration_designation: selectedValueDesigEnu,
        enumaration_branch_id: formData.organisation,
      };

      // Log the payload for debugging
      console.log('Submitting form data:', JSON.stringify(payload, null, 2));

      // Make the API PUT request to submit the data
      const response = await axios.put(apiUrl, payload, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      // Log the successful response
      console.log('Form data submitted successfully:', response.data);

      // Show success alert
      setModalVisible(true);
      // navigation.navigate('form3PartA');
    } catch (error) {
      // Log the error details for debugging
      console.error('Error submitting form data:', error);

      // If error response exists, log the response data and status code
      if (error.response) {
        console.error('Error response data:', error);
        console.error('Error response status:', error.response.status);
      }

      // Show error message from server or a generic message
      const errorMessage =
        error.response?.data?.message ||
        'Failed to submit form data. Please try again.';

      // Display the error message in an alert
      Alert.alert('Error', errorMessage);
    }
  };


  const goToDashboard = () => {
    // alert('Navigating to Dashboard...');
    setModalVisible(false);
    navigation.navigate('Home');
  };

  const createNewRecord = () => {
    // alert('Creating a new record...');
    setModalVisible(false);
    navigation.navigate('form3PartA');
  };

  //  API Completed

  return (
    <View style={styles.container}>
      {/* Header */}
      <Text style={styles.header}>
        <Text style={{color: '#8a4e28'}}>Form 3 : </Text>Farmer Baseline
        Questionnaire
      </Text>

      <View style={styles.containerTab}>
        {/* Step A */}
        <View style={styles.tabContainer}>
          <TouchableOpacity style={[styles.circle, styles.completeCircle]}>
            <Icon name="check" size={12} color="#ccc" />
          </TouchableOpacity>
          <Text style={[styles.tabText, styles.activeText]}>Part A</Text>
        </View>

        {/* Divider */}
        <View style={styles.line} />

        {/* Part B */}
        <View style={styles.tabContainer}>
          <TouchableOpacity style={[styles.circle, styles.completeCircle]}>
            <Icon name="check" size={12} color="#ccc" />
          </TouchableOpacity>
          <Text style={styles.tabText}>Part B</Text>

          <Text style={styles.tabText}>3/3</Text>
        </View>

        {/* Divider */}
        <View style={styles.line} />

        {/* Part C */}
        <View style={styles.tabContainer}>
          <TouchableOpacity style={[styles.circle, styles.activeCircle]}>
            <Icon name="check" size={12} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.tabText}>Part C</Text>
        </View>
      </View>

      <ScrollView style={{marginBottom: 6}}>
        {/* fermentary & dryer */}
        <Text style={styles.sectionTitle}>Part C: Interviewer details</Text>
        <Text style={styles.subtitle}>Enter Interviewer details here</Text>

        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={styles.label}>First Name</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter First Name"
            value={formData.interviewer_first_name}
            onChangeText={text =>
              setFormData({...formData, interviewer_first_name: text})
            }
          />
        </View>

        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={styles.label}>Last Name</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter LastName"
            value={formData.interviewer_last_name}
            onChangeText={text =>
              setFormData({...formData, interviewer_last_name: text})
            }
          />
        </View>

        <View style={styles.genderGroup}>
          <Text style={styles.heading}>Gender</Text>
          <View style={{flexDirection: 'row'}}>
            {genderOptions.map(option => (
              <TouchableOpacity
                key={option.value}
                style={styles.radioContainer}
                onPress={() => setSelectedValue(option.value)}>
                <View style={styles.radioCircle}>
                  {selectedValue === option.value && (
                    <View style={styles.selectedCircle} />
                  )}
                </View>
                <Text style={styles.radioText}>{option.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.genderGroup}>
          <Text style={styles.heading}>Designation</Text>
          <View style={{flexDirection: 'row'}}>
            {designationOptions.map(option => (
              <TouchableOpacity
                key={option.value}
                style={styles.radioContainer}
                onPress={() => setSelectedDesig(option.value)}>
                <View style={styles.radioCircle}>
                  {SelectedDesig === option.value && (
                    <View style={styles.selectedCircle} />
                  )}
                </View>
                <Text style={styles.radioText}>{option.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* tools details */}
        <Text style={styles.sectionTitle}>
          Part C: Interviewer Division/Section
        </Text>
        <Text style={styles.subtitle}>Enter Interviewer details here</Text>

        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={[styles.label, isFocused && styles.focusedLabel]}>
            Division
          </Text>
          <Picker
            selectedValue={formData.division}
            style={styles.input}
            onValueChange={value =>
              setFormData({...formData, division: value})
            }>
            <Picker.Item
              label="Select Division here"
              value=""
              style={styles.pickItem}
            />
            <Picker.Item
              label="devision 1"
              value="devision 1"
              style={styles.pickItem}
            />
            <Picker.Item
              label="devision 2"
              value="devision 2"
              style={styles.pickItem}
            />
          </Picker>
        </View>

        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={[styles.label, isFocused && styles.focusedLabel]}>
            Project
          </Text>
          <Picker
            selectedValue={formData.project}
            style={styles.input}
            onValueChange={value => setFormData({...formData, project: value})}>
            <Picker.Item
              label="Select Project here"
              value=""
              style={styles.pickItem}
            />
            <Picker.Item
              label="Project 1"
              value="Project 1"
              style={styles.pickItem}
            />
            <Picker.Item
              label="Project 2"
              value="Project 2"
              style={styles.pickItem}
            />
          </Picker>
        </View>

        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={[styles.label, isFocused && styles.focusedLabel]}>
            Office Location
          </Text>
          <Picker
            selectedValue={formData.office_location}
            style={styles.input}
            onValueChange={value =>
              setFormData({...formData, office_location: value})
            }>
            <Picker.Item
              label="Select Location here"
              value=""
              style={styles.pickItem}
            />
            <Picker.Item
              label="Location 1"
              value="Location 1"
              style={styles.pickItem}
            />
            <Picker.Item
              label="Location 2"
              value="Location 2"
              style={styles.pickItem}
            />
          </Picker>
        </View>

        {/* Training Details */}
        <Text style={styles.sectionTitle}>Part C: Other Enumerator</Text>
        <Text style={styles.subtitle}>Enter other enumerator here</Text>

        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={styles.label}>First Name</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter FirstName"
            value={formData.enu_first_name}
            onChangeText={text => setFormData({...formData, enu_first_name: text})}
          />
        </View>

        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={styles.label}>Last Name</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter LastName"
            value={formData.enu_last_name}
            onChangeText={text => setFormData({...formData, enu_last_name: text})}
          />
        </View>

        <View style={styles.genderGroup}>
          <Text style={styles.heading}>Gender</Text>
          <View style={{flexDirection: 'row'}}>
            {genderOptions.map(option => (
              <TouchableOpacity
                key={option.value}
                style={styles.radioContainer}
                onPress={() => setSelectedValueEnuGender(option.value)}>
                <View style={styles.radioCircle}>
                  {selectedValueEnuGender === option.value && (
                    <View style={styles.selectedCircle} />
                  )}
                </View>
                <Text style={styles.radioText}>{option.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.genderGroup}>
          <Text style={styles.heading}>Designation</Text>
          <View style={{flexDirection: 'row'}}>
            {designationOptions.map(option => (
              <TouchableOpacity
                key={option.value}
                style={styles.radioContainer}
                onPress={() => setSelectedValueDesigEnu(option.value)}>
                <View style={styles.radioCircle}>
                  {selectedValueDesigEnu === option.value && (
                    <View style={styles.selectedCircle} />
                  )}
                </View>
                <Text style={styles.radioText}>{option.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={[styles.label, isFocused && styles.focusedLabel]}>
            Organisation
          </Text>
          <Picker
            selectedValue={formData.organisation}
            style={styles.input}
            onValueChange={value =>
              setFormData({...formData, organisation: value})
            }>
            <Picker.Item
              label="Select Location here"
              value=""
              style={styles.pickItem}
            />
            <Picker.Item
              label="Organisation 1"
              value="Organisation 1"
              style={styles.pickItem}
            />
            <Picker.Item
              label="Organisation 2"
              value="Organisation 2"
              style={styles.pickItem}
            />
          </Picker>
        </View>
      </ScrollView>

      <TouchableOpacity
        onPress={() => updateFarmerDataB3(formData, navigation)}
        style={styles.savebtn}>
        <Text style={styles.savebtnText}>
          Save
        </Text>
      </TouchableOpacity>

      <Modal
        animationType="fade"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.successIcon}>✔️</Text>
            <Text style={styles.modalText}>
              Your Registration has successfully been submitted!
            </Text>
            <TouchableOpacity
              style={[styles.button, styles.primaryButton]}
              onPress={goToDashboard}>
              <Text style={styles.buttonText}>Back to Dashboard</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.button, styles.secondaryButton]}
              onPress={createNewRecord}>
              <Text style={styles.buttonText}>Create New Record</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  containerTab: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    backgroundColor: '#f7efe7',
    marginBottom: 10,
  },
  tabContainer: {
    alignItems: 'center',
    flexDirection: 'column',
  },
  circle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#ccc',
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeCircle: {
    backgroundColor: '#8a4e28', // Matches the active color in the example
  },

  completeCircle: {
    backgroundColor: '#02A552',
  },
  tabText: {
    marginTop: 4,
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  activeText: {
    color: '#000', // Active text color
    fontWeight: 'bold',
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: '#ccc',
    marginHorizontal: 8,
    marginTop: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    color: '#8a4e28',
  },
  subtitle: {
    fontSize: 12,
    color: '#666',
    marginBottom: 16,
    color: '#2F7F6A',
  },
  field: {
    marginBottom: 16,
  },
  inputRow: {
    marginVertical: 15,
    flexDirection: 'row',
  },
  input: {
    borderRadius: 5,
    backgroundColor: '#F7F7F7',
  },
  picker: {
    fontSize: 10,
    height: 40,
    backgroundColor: '#F7F7F7',
  },
  pickItem: {
    fontSize: 14,
  },
  containerInput: {
    position: 'relative',
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginVertical: 10,
  },
  label: {
    position: 'absolute',
    top: -10,
    left: 10,
    backgroundColor: '#fff',
    paddingHorizontal: 5,
    fontSize: 12,
    color: '#ccc',
  },
  label1: {
    position: 'absolute',
    top: -15,
    left: 10,
    backgroundColor: '#fff',
    paddingHorizontal: 5,
    fontSize: 12,
    color: '#949494',
  },
  focusedLabel: {
    color: '#000',
  },
  heading: {
    fontSize: 14,
    fontWeight: 'bold',
    marginRight: 10,
  },
  radioContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: 10,
  },
  radioCircle: {
    height: 15,
    width: 15,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#ccc',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 5,
  },
  selectedCircle: {
    height: 10,
    width: 10,
    borderRadius: 5,
    backgroundColor: '#ccc',
  },
  radioText: {
    fontSize: 12,
    color: '#333',
  },
  ageInput: {
    flex: 1,
    marginRight: 8,
  },
  radioGroup: {
    flexDirection: 'row',
    flex: 1,
  },
  selectedGender: {
    backgroundColor: '#8a4e28',
    color: '#fff',
  },
  uploadButton: {
    flex: 2,
    padding: 8,
    backgroundColor: '#F2F2F2',
    borderRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
  },
  photoPreview: {
    width: 40,
    height: 40,
    marginTop: 8,
    borderRadius: 20,
  },
  savebtn: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 300,
    height: 50,
    marginHorizontal: 25,
    backgroundColor: '#ecded5',
    borderRadius: 10,
  },
  savebtnText: {
    fontSize: 18,
    color: '#9d562b',
  },
  textArea: {
    width: '100%',
    height: 70,
    borderRadius: 8,
    padding: 10,
    textAlignVertical: 'top',
    backgroundColor: '#F7F7F7',
  },
});

export default FarmerForm5;
