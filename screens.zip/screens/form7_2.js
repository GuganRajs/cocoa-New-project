import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
  ScrollView,
  Modal,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Picker} from '@react-native-picker/picker';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DatePickers from '../components/utils/DatePickers';

const Form7_2 = ({route}) => {
  const {data} = route.params; // Destructure to extract 'data'
  // console.log(data.board_of_director);
  const navigation = useNavigation();
  const [formData, setFormData] = useState({
    training_details: [
      {
        capacity: '',
        targetGroup: '',
        inspection_date: '',
        location: '',
        trainer: '',
      },
    ],
    members_and_shareholders: [
      {
        age: '',
        blocks: '',
        date: '',
        name: '',
        trees: '',
        youthOrDisabled: '',
      },
    ],
  });
  const [modalVisible, setModalVisible] = useState(false);

  const entityRegisterOptions = [
    {label: 'Yes', value: 'Yes'},
    {label: 'No', value: 'No'},
  ];

  const bankAccountOptions = [
    {label: 'Yes', value: 'Yes'},
    {label: 'No', value: 'No'},
  ];

  const stateregistrationOptions = [
    {label: 'Valid', value: 'Valid'},
    {label: 'Expired', value: 'Expired'},
  ];

  const addTrainingField = () => {
    setFormData(prevState => ({
      ...prevState,
      training_details: [
        ...prevState.training_details,
        {
          capacity: '',
          targetGroup: '',
          inspection_date: '',
          location: '',
          trainer: '',
        },
      ],
    }));
  };

  const addMemberField = () => {
    setFormData(prevState => ({
      ...prevState,
      members_and_shareholders: [
        ...prevState.members_and_shareholders,
        {
          age: '',
          blocks: '',
          date: '',
          name: '',
          trees: '',
          youthOrDisabled: '',
        },
      ],
    }));
  };

  const preparePayload = () => {
    const payload = {
      bank_branch: data.bank_branch,
      bank_name: data.bank_name,
      board_of_director: data.board_of_director,
      created_at: data.created_at,
      created_branch_id: data.created_branch_id,
      created_designation_id: data.created_designation_id,
      created_user_id: data.created_user_id,
      district_id: data.district_id,
      farmer_group_name: data.farmer_group_name,
      is_bank_account: data.is_bank_account,
      is_registered: data.is_registered,
      id: data.id,
      llg_id: data.llg_id,
      management_team: data.management_team,
      members_and_shareholders: formData.members_and_shareholders.map(
        member => ({
          age: member.age,
          blocks: member.blocks,
          date: member.date,
          name: member.name,
          trees: member.trees,
          youthOrDisabled: member.youthOrDisabled,
        }),
      ),
      officially_formed: data.officially_formed,
      province_id: data.province_id,
      region_id: data.region_id,
      registered_on: data.registered_on,
      registered_with_who: data.registered_with_who,
      state_of_registration: data.state_of_registration,
      training_details: formData.training_details.map(training => ({
        capacity: training.capacity,
        date: training.inspection_date,
        location: training.location,
        targetGroup: training.targetGroup,
        trainer: training.trainer,
      })),
      updated_at: new Date(),
      ward_id: data.ward_id,
      region: {
        region_code: data.region.region_code,
        updated_at: new Date(),
        region_name: data.region.region_name,
        created_at: data.region.created_at,
        id: data.region.id,
      },
      province: {
        p_fermentary_code: data.province.p_fermentary_code,
        id: data.province.id,
        created_at: data.province.created_at,
        province_name: data.province.province_name,
        province_code: data.province.province_code,
        region_id: data.province.region_id,
        updated_at: new Date(),
      },
      district: {
        district_code: data.district.district_code,
        district_name: data.district.district_name,
        province_id: data.district.province_id,
        created_at: data.district.created_at,
        id: data.district.id,
        d_fermentary_code: data.district.d_fermentary_code,
        region_id: data.district.region_id,
        updated_at: new Date(),
      },
      llg: {
        llg_name: data.llg.llg_name,
        llg_code: data.llg.llg_code,
        district_id: data.llg.district_id,
        region_id: data.llg.region_id,
        updated_at: new Date(),
        id: data.llg.id,
        l_fermentary_code: data.llg.l_fermentary_code,
        province_id: data.llg.province_id,
        created_at: data.llg.created_at,
      },
      ward: {
        id: data.ward.id,
        llg_id: data.ward.llg_id,
        province_id: data.ward.province_id,
        created_at: data.ward.created_at,
        ward_name: data.ward.ward_name,
        ward_code: data.ward.ward_code,
        district_id: data.ward.district_id,
        region_id: data.ward.region_id,
        updated_at: new Date(),
      },
    };

    // console.log('Final Payload:', payload);
    return payload;
  };

  const submitData = async () => {
    // alert();
    try {
      const payload = preparePayload();
      const token = await AsyncStorage.getItem('access_token');
      const response = await axios.put(
        `http://159.13.36.60:8000/api/farmergroups/${data.id}`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        },
      );
      console.log('Submission Successful:', response.data);
      setModalVisible(true);
    } catch (error) {
      console.error('Submission Error:', error);
      alert('Failed to submit data. Please try again.');
    }
  };

  const goToDashboard = () => {
    // alert('Navigating to Dashboard...');
    setModalVisible(false);
    navigation.navigate('Home');
  };

  const createNewRecord = () => {
    // alert('Creating a new record...');
    setModalVisible(false);
    navigation.navigate('form7');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>
        <Text style={{color: '#8a4e28'}}>Form 7 : </Text>Cocoa Farmer Group and
        Cooperative Profile
      </Text>

      <View style={styles.containerTab}>
        {/* Step A */}
        <View style={styles.tabContainer}>
          <TouchableOpacity style={[styles.circle, styles.completeCircle]}>
            <Icon name="check" size={12} color="#fff" />
          </TouchableOpacity>
          <Text style={[styles.tabText, styles.activeText]}>1/2</Text>
        </View>

        {/* Divider */}
        <View style={styles.line} />

        {/* Part B */}
        <View style={styles.tabContainer}>
          <TouchableOpacity style={[styles.circle, styles.activeCircle]}>
            <Icon name="check" size={12} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.tabText}>2/2</Text>
        </View>
      </View>

      <ScrollView style={{marginBottom: 6}}>
        {/* Training and target */}
        <Text style={styles.sectionTitle}>
          Training and target group of Entity
        </Text>
        <Text style={styles.subtitle}>
          Enter list and indicate type of capacity building training and target
          group within the entity that has attended training details here
        </Text>

        {formData.training_details.map((training, index) => (
          <View key={index}>
            {index > 0 ? (
              <TouchableOpacity
                style={{position: 'absolute', right: 10, top: -10, zIndex: 1}}
                onPress={() => {
                  const updatedTrainings = formData.training_details.filter(
                    (_, i) => i !== index,
                  );
                  setFormData({
                    ...formData,
                    training_details: updatedTrainings,
                  });
                }}>
                <View style={styles.circleLineRemove}>
                  <Text style={styles.innerCircleRemove}>X</Text>
                </View>
              </TouchableOpacity>
            ) : (
              ''
            )}

            <View style={styles.containerInput}>
              <Text style={styles.label}>Capacity Building Trainings</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter here"
                value={training.capacity}
                onChangeText={text => {
                  const updatedTrainings = [...formData.training_details];
                  updatedTrainings[index].capacity = text;
                  setFormData({
                    ...formData,
                    training_details: updatedTrainings,
                  });
                }}
              />
            </View>

            <View style={styles.containerInput}>
              <Text style={styles.label}>Target Group</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter here"
                value={training.targetGroup}
                onChangeText={text => {
                  const updatedTrainings = [...formData.training_details];
                  updatedTrainings[index].targetGroup = text;
                  setFormData({
                    ...formData,
                    training_details: updatedTrainings,
                  });
                }}
              />
            </View>

            <View style={styles.inputRow}>
              <View style={[styles.containerInput, {flex: 1, marginRight: 5}]}>
                <DatePickers
                  label="Date"
                  value={training.inspection_date}
                  onChange={date => {
                    const updatedTrainings = [...formData.training_details];
                    updatedTrainings[index].inspection_date = date.value;
                    setFormData({
                      ...formData,
                      training_details: updatedTrainings,
                    });
                  }}
                  placeholder="DD-MM-YYYY"
                />
              </View>

              <View style={[styles.containerInput, {flex: 1}]}>
                <Text style={styles.label}>Location</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter location"
                  value={training.location}
                  onChangeText={text => {
                    const updatedTrainings = [...formData.training_details];
                    updatedTrainings[index].location = text;
                    setFormData({
                      ...formData,
                      training_details: updatedTrainings,
                    });
                  }}
                />
              </View>
            </View>

            <View style={{marginTop: -20, marginBottom: 20}}>
              <View style={[styles.containerInput]}>
                <Text style={styles.label}>Trainer (s) & organisation</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter Trainer here"
                  value={training.trainer}
                  onChangeText={text => {
                    const updatedTrainings = [...formData.training_details];
                    updatedTrainings[index].trainer = text;
                    setFormData({
                      ...formData,
                      training_details: updatedTrainings,
                    });
                  }}
                />
              </View>
            </View>
          </View>
        ))}

        <TouchableOpacity
          style={styles.radioContainer}
          onPress={addTrainingField}>
          <View style={styles.lineAdd} />
          <View style={styles.circleLine}>
            <Text style={styles.innerCircle}>+</Text>
          </View>
          <View style={styles.lineAdd} />
        </TouchableOpacity>

        {/* Members & Shareholders */}
        <Text style={styles.sectionTitle}>List of Members & Shareholders</Text>
        <Text style={styles.subtitle}>
          Enter list of members & shareholders here
        </Text>

        {formData.members_and_shareholders.map((member, index) => (
          <View key={index}>
            {index > 0 ? (
              <TouchableOpacity
                style={{position: 'absolute', right: 10, top: -10, zIndex: 1}}
                onPress={() => {
                  const updatedMembers =
                    formData.members_and_shareholders.filter(
                      (_, i) => i !== index,
                    );
                  setFormData({
                    ...formData,
                    members_and_shareholders: updatedMembers,
                  });
                }}>
                <View style={styles.circleLineRemove}>
                  <Text style={styles.innerCircleRemove}>X</Text>
                </View>
              </TouchableOpacity>
            ) : (
              ''
            )}

            <View style={styles.containerInput}>
              <Text style={styles.label}>Name of Farmer</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter here"
                value={member.name}
                onChangeText={text => {
                  const updatedMembers = [...formData.members_and_shareholders];
                  updatedMembers[index].name = text;
                  setFormData({
                    ...formData,
                    members_and_shareholders: updatedMembers,
                  });
                }}
              />
            </View>

            <View style={styles.inputRow}>
              <View style={[styles.containerInput, {flex: 1, marginRight: 5}]}>
                <Text style={styles.label}>Age</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter here"
                  value={member.age}
                  onChangeText={text => {
                    const updatedMembers = [
                      ...formData.members_and_shareholders,
                    ];
                    updatedMembers[index].age = text;
                    setFormData({
                      ...formData,
                      members_and_shareholders: updatedMembers,
                    });
                  }}
                />
              </View>

              <View style={[styles.containerInput, {flex: 1}]}>
                <Text style={styles.label}>Youth or Disable</Text>
                <Picker
                  selectedValue={member.youthOrDisabled}
                  style={([styles.input], {backgroundColor: '#F7F7F7'})}
                  onValueChange={(itemValue, itemIndex) => {
                    const updatedMembers = [...formData.training_details];
                    updatedMembers[index].youthOrDisabled = itemValue;
                    setFormData({
                      ...formData,
                      training_details: updatedMembers,
                    });
                  }}>
                  <Picker.Item
                    label="Select here"
                    value=""
                    style={styles.pickItem}
                  />
                  <Picker.Item
                    label="Youth"
                    value="Youth"
                    style={styles.pickItem}
                  />
                  <Picker.Item
                    label="Disabled"
                    value="Disabled"
                    style={styles.pickItem}
                  />
                </Picker>
              </View>
            </View>

            <View style={styles.inputRow}>
              <View
                style={([styles.containerInput], {flex: 1, marginRight: 5})}>
                <Text style={styles.label}>No. of Cocoa Plot or Blocks</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter here"
                  value={member.blocks}
                  onChangeText={text => {
                    const updatedMembers = [
                      ...formData.members_and_shareholders,
                    ];
                    updatedMembers[index].blocks = text;
                    setFormData({
                      ...formData,
                      members_and_shareholders: updatedMembers,
                    });
                  }}
                />
              </View>

              <View style={([styles.containerInput], {flex: 1})}>
                <Text style={styles.label}>No. of Cocoa Trees</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter here"
                  value={member.trees}
                  onChangeText={text => {
                    const updatedMembers = [
                      ...formData.members_and_shareholders,
                    ];
                    updatedMembers[index].trees = text;
                    setFormData({
                      ...formData,
                      members_and_shareholders: updatedMembers,
                    });
                  }}
                />
              </View>
            </View>

            <View style={styles.containerInput}>
              <DatePickers
                label="Date"
                value={member.date}
                onChange={date => {
                  const updatedMembers = [...formData.members_and_shareholders];
                  updatedMembers[index].date = date.value;
                  setFormData({
                    ...formData,
                    members_and_shareholders: updatedMembers,
                  });
                }}
                placeholder="DD-MM-YYYY"
              />
            </View>
          </View>
        ))}

        <TouchableOpacity
          style={styles.radioContainer}
          onPress={addMemberField}>
          <View style={styles.lineAdd} />
          <View style={styles.circleLine}>
            <Text style={styles.innerCircle}>+</Text>
          </View>
          <View style={styles.lineAdd} />
        </TouchableOpacity>
      </ScrollView>

      <TouchableOpacity onPress={submitData} style={styles.savebtn}>
        <Text style={styles.savebtnText}>
          Sava <Icon name="arrow-right" size={12} />
        </Text>
      </TouchableOpacity>

      <Modal
        animationType="fade"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.successIcon}>✔️</Text>
            <Text style={styles.modalText}>
              Your Registration has successfully been submitted!
            </Text>
            <TouchableOpacity
              style={[styles.button, styles.primaryButton]}
              onPress={goToDashboard}>
              <Text style={styles.buttonText}>Back to Dashboard</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.button, styles.secondaryButton]}
              onPress={createNewRecord}>
              <Text style={styles.buttonText}>Create New Record</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  containerTab: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    backgroundColor: '#f7efe7',
    marginBottom: 10,
  },
  tabContainer: {
    alignItems: 'center',
    flexDirection: 'column',
  },
  circle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#ccc',
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeCircle: {
    backgroundColor: '#8a4e28', // Matches the active color in the example
  },

  completeCircle: {
    backgroundColor: '#02A552',
  },
  tabText: {
    marginTop: 4,
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  activeText: {
    color: '#000', // Active text color
    fontWeight: 'bold',
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: '#ccc',
    marginHorizontal: 8,
    marginTop: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    color: '#8a4e28',
  },
  subtitle: {
    fontSize: 12,
    color: '#666',
    marginBottom: 16,
    color: '#2F7F6A',
  },
  containerInput: {
    position: 'relative',
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginVertical: 10,
  },
  label: {
    position: 'absolute',
    left: 10,
    zIndex: 1,
    paddingHorizontal: 5,
    fontSize: 12,
    color: '#949494',
  },
  input: {
    borderRadius: 5,
    backgroundColor: '#F7F7F7',
  },
  textArea: {
    width: '100%',
    height: 70,
    borderRadius: 8,
    padding: 10,
    textAlignVertical: 'top',
    backgroundColor: '#F7F7F7',
  },
  pickItem: {
    fontSize: 14,
  },
  heading: {
    fontSize: 14,
    fontWeight: 'bold',
    marginRight: 10,
  },
  radioGroup: {
    flexDirection: 'row',
    flex: 1,
  },
  radioContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: 10,
  },
  radioCircle: {
    height: 15,
    width: 15,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#ccc',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 5,
  },
  selectedCircle: {
    height: 10,
    width: 10,
    borderRadius: 5,
    backgroundColor: '#ccc',
  },
  radioText: {
    fontSize: 12,
    color: '#333',
  },
  inputRow: {
    flexDirection: 'row',
  },
  lineAdd: {
    flex: 1, // Makes the line take up available space
    height: 2,
    backgroundColor: '#B1B1B1',
  },
  circleLine: {
    width: 30,
    height: 30,
    borderRadius: 15, // Makes the element circular
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: 'brown',
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 5,
  },
  circleLineRemove: {
    width: 20,
    height: 20,
    borderRadius: 15, // Makes the element circular
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: 'brown',
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 5,
  },
  innerCircle: {
    fontSize: 20,
    fontWeight: 'bold',
    borderColor: 'brown',
  },
  innerCircleRemove: {
    fontSize: 10,
    fontWeight: 'bold',
    borderColor: 'brown',
  },
  savebtn: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 300,
    height: 50,
    marginHorizontal: 25,
    backgroundColor: '#F7F7F7',
    borderRadius: 10,
  },
  savebtnText: {
    fontSize: 18,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
    width: '85%',
  },
  successIcon: {
    fontSize: 48,
    color: 'green',
    marginBottom: 10,
  },
  modalText: {
    fontSize: 18,
    color: '#333',
    textAlign: 'center',
    marginBottom: 20,
  },
  button: {
    width: '100%',
    padding: 12,
    borderRadius: 5,
    marginTop: 10,
    alignItems: 'center',
  },
  primaryButton: {
    backgroundColor: '#a0522d',
  },
  secondaryButton: {
    backgroundColor: '#333',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
});

export default Form7_2;
