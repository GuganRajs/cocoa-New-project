import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
  ScrollView,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Picker} from '@react-native-picker/picker';
import {useNavigation} from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker'; // Using the built-in API without additional libraries

const FarmerForm = () => {
  const navigation = useNavigation();
  const [formData, setFormData] = useState({
    title: 'Mr',
    firstName: '',
    lastName: '',
    age: '0',
    gender: 'Male',
    MaritalStatus: '',
    mobileNumber: '',
    dependetChild: '',
    highestQualification: '',
    bankAccount: '',
    bankbranch: '',
    region: '',
    province: '',
    photo: null,
  });
  const [selectedTitle, setSelectedTitle] = useState();
  const [isFocused, setIsFocused] = useState(false);
  const [selectedValue, setSelectedValue] = useState('No');
  const [regions, setRegions] = useState([]);
  const [provinces, setProvinces] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [llgs, setLlgs] = useState([]); // LLG data state
  const [wards, setWards] = useState([]); // Village/Ward data state
  const [selectedGender, setSelectedGender] = useState('');
  const [selectedBankBranch, bankbranch] = useState('');

  const genderOptions = [
    {label: 'Male', value: 'male'},
    {label: 'Female', value: 'female'},
    {label: 'Other', value: 'other'},
  ];

  const bankExistOptions = [
    {label: 'Yes', value: 'Yes'},
    {label: 'No', value: 'No'},
  ];
  // Fetch regions from the API
  useEffect(() => {
    fetchRegions();
  }, []);

  const fetchRegions = async () => {
    console.log('Fetching regions...');
    try {
      const token = await AsyncStorage.getItem('access_token');
      const apiUrl = 'http://159.13.36.60:8000/api/regions/all';
      const response = await axios.get(apiUrl, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      console.log('Fetched regions:', response.data);
      setRegions(response.data); // Populate regions with fetched data
    } catch (error) {
      console.error('Error fetching regions:', error);
    }
  };

  // Fetch provinces based on selected region ID
  const fetchProvinces = async regionId => {
    try {
      const token = await AsyncStorage.getItem('access_token');
      const apiUrl = `http://159.13.36.60:8000/api/provinces/all/${regionId}`;
      const response = await axios.get(apiUrl, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setProvinces(response.data);
      setDistricts([]); // Clear districts when region/province is changed
    } catch (error) {
      console.error('Error fetching provinces:', error);
    }
  };

  // Fetch provinces based on selected prov ID
  const fetchDistrict = async provinceId => {
    try {
      const token = await AsyncStorage.getItem('access_token');
      const apiUrl = `http://159.13.36.60:8000/api/districts/all/${provinceId}`;
      const response = await axios.get(apiUrl, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setDistricts(response.data);
      setLlgs([]);
    } catch (error) {
      console.error('Error fetching districts:', error);
    }
  };

  const fetchLLGs = async districtId => {
    try {
      const token = await AsyncStorage.getItem('access_token');
      const apiUrl = `http://159.13.36.60:8000/api/llgs/all/${districtId}`;
      const response = await axios.get(apiUrl, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setLlgs(response.data);
      setWards([]); // Clear wards when LLG is changed
    } catch (error) {
      console.error('Error fetching LLGs:', error);
    }
  };

  // Fetch wards based on selected LLG
  const fetchWards = async llgId => {
    try {
      const token = await AsyncStorage.getItem('access_token');
      const apiUrl = `http://159.13.36.60:8000/api/wards/all/${llgId}`;
      const response = await axios.get(apiUrl, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setWards(response.data);
    } catch (error) {
      console.error('Error fetching wards:', error);
    }
  };

//   const submitFarmerData = async (formdata, navigation) => {
//  navigation.navigate('form3PartB');
//   }

  const submitFarmerData = async (formData, navigation) => {
    console.log(formData.selectedGender);

    // Check if mandatory fields are filled
    if (
      !formData.firstName ||
      !formData.region ||
      !formData.lastName ||
      !formData.mobileNumber ||
      !formData.province ||
      !formData.district ||
      !formData.LLG ||
      !formData.village ||
      !formData.MaritalStatus
    ) {
      alert('please fill mandatory fields');
      return; // Stop form submission
    }
    try {
      const token = await AsyncStorage.getItem('access_token'); // Retrieve token
      const apiUrl = 'http://159.13.36.60:8000/api/farmers/create'; // API endpoint

      // Prepare payload
      const payload = {
        title: selectedTitle,
        farmer_first_name: formData.firstName,
        farmer_last_name: formData.lastName,
        gender: selectedGender,
        age: formData.age,
        phone: formData.mobileNumber,
        region_id: formData.region,
        province_id: formData.province,
        district_id: formData.district,
        llg_id: formData.LLG,
        ward_id: formData.village,
        marital_status: formData.MaritalStatus,
        no_of_children: formData.dependetChild,
        edu_qualification: formData.highestQualification,
        is_bank_account: false,
        bank_name: formData.bankAccount,
        bank_branch: formData.bankbranch,
        is_records_of_cocoa_sales: false,
        what_type_of_records: '',
        no_of_cocoa_plots: 0,
        no_of_cocoa_plots_planted: 0,
        name_of_plots: [],
        no_of_trees: [],
        total_no_of_trees: 0,
        planted_year: [],
        planting_material: [],
        variety_of_cocoa: [],
        is_replanting_plan: [],
        replanting_variety: [],
        is_cocoa_certification: false,
        certification_program: '',
        cocoa_fermentary_details: '',
        fermentary_id: '',
        fermentary_code: '',
        fermentary_number: '',
        is_fermentary_register: false,
        fermentary_register_date: '',
        wetbean_produce_year_kgs: '',
        is_sell_wetbean: false,
        wetbean_sell_year_kgs: '',
        wetbean_avg_price: '',
        wetbean_total_earned: '',
        drybean_bag_sell_last_year: '',
        drybean_sell_to: '',
        drybean_earned_last_year: '',
        drybean_avg_price: '',
        drybean_bag_transport_cost: '',
        drybean_how_you_sell: '',
        is_member_of_farmer_group: false,
        farmergroups_id: '',
        farmer_group_name: '',
        cocoa_farming_system: '',
        form_of_income_source: [],
        name_of_the_echo_business: '',
        mode_of_transport: '',
        cost_of_transport: '',
        is_cocoa_tool: false,
        cocoa_tool_details: [
          {
            tool: '',
            quantity: '',
            condition: '',
            supplier: '',
          },
        ],
        last_tech_officer_visited: '',
        officer_organisation: '',
        training_do_you_lack: '',
        other_comments: '',
        training_details: [
          {
            training: '',
            date: '',
            location: '',
            organisation: '',
          },
        ],
        interviewer_title: 'Mr',
        interviewer_first_name: '',
        interviewer_last_name: '',
        interviewer_gender: '',
        interviewer_designation: '',
        interviewer_division_id: '',
        interviewer_project_id: '',
        interviewer_branch_id: '',
        enumaration_title: 'Mr',
        enumaration_first_name: '',
        enumaration_last_name: '',
        enumaration_gender: '',
        enumaration_designation: '',
        enumaration_branch_id: '',
      };

      console.log('Submitting farmer data:', JSON.stringify(payload, null, 2));

      // API call
      const response = await axios.post(apiUrl, payload, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      console.log('Farmer data submitted successfully:', response.data);
      const farmerId = response.data.id; // Assuming 'id' is returned in the response
      await AsyncStorage.setItem('farmerId', farmerId.toString());
      alert('Farmerssss data submitted successfully!');
      //   navigation.goBack();
      navigation.navigate('form3PartB', {
        title: selectedTitle,
        farmer_first_name: formData.firstName,
        farmer_last_name: formData.lastName,
        gender: selectedGender,
        age: formData.age,
        phone: formData.mobileNumber,
        region_id: formData.region,
        province_id: formData.province,
        district_id: formData.district,
        llg_id: formData.LLG,
        ward_id: formData.village,
        marital_status: formData.MaritalStatus,
        no_of_children: formData.dependetChild,
        edu_qualification: formData.highestQualification,
        is_bank_account: false,
        bank_name: formData.bankAccount,
        bank_branch: formData.bankbranch,
      });
    } catch (error) {
      console.error('Error submitting farmer data:', error);
      const errorMessage =
        error.response?.data?.message ||
        'Failed to submit farmer data. Please try again.';
      alert(errorMessage);
    }
  };

  // submit form completed

  return (
    <View style={styles.container}>
      {/* Header */}
      <Text style={styles.header}>
        <Text style={{color: '#8a4e28'}}>Form 3 : </Text>Farmer Baseline
        Questionnaire
      </Text>

      <View style={styles.containerTab}>
        {/* Step A */}
        <View style={styles.tabContainer}>
          <TouchableOpacity style={[styles.circle, styles.activeCircle]}>
            <Icon name="check" size={12} color="#fff" />
          </TouchableOpacity>
          <Text style={[styles.tabText, styles.activeText]}>Part A</Text>
        </View>

        {/* Divider */}
        <View style={styles.line} />

        {/* Part B */}
        <View style={styles.tabContainer}>
          <TouchableOpacity style={styles.circle}>
            <Icon name="check" size={12} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.tabText}>Part B</Text>
        </View>

        {/* Divider */}
        <View style={styles.line} />

        {/* Part C */}
        <View style={styles.tabContainer}>
          <TouchableOpacity style={styles.circle}>
            <Icon name="check" size={12} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.tabText}>Part C</Text>
        </View>
      </View>

      <ScrollView style={{marginBottom: 6}}>
        {/* Form */}
        <Text style={styles.sectionTitle}>Part A: Farmer Details</Text>
        <Text style={styles.subtitle}>
          Enter Farmer basic details and address below
        </Text>

        {/* Title */}
        <View style={styles.inputRow}>
          <View
            style={
              ([styles.containerInput, isFocused && styles.focusedContainer],
              {flex: 1})
            }>
            <Text style={styles.label1}>Title</Text>
            <Picker
              selectedValue={selectedTitle}
              style={([styles.input], {width: 120, backgroundColor: '#F7F7F7'})}
              //   onValueChange={itemValue => setSelectedValue(itemValue)}
              onValueChange={(itemValue, itemIndex) =>
                setSelectedTitle(itemValue)
              }>
              <Picker.Item label="Mr" value="Mr" style={styles.pickItem} />
              <Picker.Item label="Ms" value="Ms" style={styles.pickItem} />
              <Picker.Item
                label="Other"
                value="Other"
                style={styles.pickItem}
              />
            </Picker>
          </View>

          <View
            style={
              ([styles.containerInput, isFocused && styles.focusedContainer],
              {flex: 2})
            }>
            <Text style={styles.label1}>FirstName *</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter your First Name"
              value={formData.firstName}
              onChangeText={text => setFormData({...formData, firstName: text})}
            />
          </View>
        </View>

        {/* Last Name */}
        {/*<View style={styles.field}>*/}
        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={[styles.label1, isFocused && styles.focusedLabel]}>
            LastName*
          </Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your Last Name"
            value={formData.lastName}
            onChangeText={text => setFormData({...formData, lastName: text})}
          />
        </View>
        {/*</View>*/}

        {/* Age and Gender */}
        <View style={styles.row}>
          <View
            style={
              ([styles.containerInput, isFocused && styles.focusedContainer],
              {flex: 1, marginRight: 10})
            }>
            <Text style={styles.label1}>Age*</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter your Age"
              value={formData.age}
              onChangeText={text => setFormData({...formData, age: text})}
            />
          </View>
          <View style={styles.genderGroup}>
            <Text style={styles.heading}>Gender*</Text>
            {genderOptions.map(option => (
              <TouchableOpacity
                key={option.value}
                style={styles.radioContainer}
                onPress={() => setSelectedGender(option.value)} // Update selected gender
              >
                <View style={styles.radioCircle}>
                  {selectedGender === option.value && (
                    <View style={styles.selectedCircle} />
                  )}
                </View>
                <Text style={styles.radioText}>{option.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Mobile Number */}
        {/*<View style={styles.field}>*/}
        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={[styles.label, isFocused && styles.focusedLabel]}>
            Mobile Number*
          </Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your mobile number here"
            keyboardType="phone-pad"
            value={formData.mobileNumber}
            onChangeText={text =>
              setFormData({...formData, mobileNumber: text})
            }
          />
        </View>
        {/* Photo Upload */}
        <View style={styles.row}>
          <Text style={styles.heading}>Upload photo</Text>
          <TouchableOpacity style={styles.uploadButton}>
            <Text>Choose photo</Text>
          </TouchableOpacity>
          {formData.photo && (
            <Image source={{uri: formData.photo}} style={styles.photoPreview} />
          )}
        </View>
        {/* Region */}
        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={[styles.label, isFocused && styles.focusedLabel]}>
            Region*
          </Text>
          <Picker
            selectedValue={formData.region}
            style={styles.input}
            onValueChange={value => {
              setFormData({...formData, region: value});
              fetchProvinces(value); // Fetch provinces based on selected region ID
            }}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}>
            <Picker.Item
              label="Select your Region here"
              value=""
              style={styles.pickItem}
            />
            {Array.isArray(regions) &&
              regions.map(region => (
                <Picker.Item
                  key={region.id}
                  label={region.region_name}
                  value={region.id}
                  style={styles.pickItem}
                />
              ))}
          </Picker>
        </View>
        {/* province */}
        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={[styles.label, isFocused && styles.focusedLabel]}>
            Province*
          </Text>
          <Picker
            selectedValue={formData.province}
            style={styles.input}
            onValueChange={value => {
              setFormData({...formData, province: value});
              fetchDistrict(value); // Fetch provinces based on selected region ID
            }}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}>
            <Picker.Item
              label="Select your Province here"
              value=""
              style={styles.pickItem}
            />
            {Array.isArray(provinces) &&
              provinces.map(province => (
                <Picker.Item
                  key={province.id}
                  label={province.province_name}
                  value={province.id}
                  style={styles.pickItem}
                />
              ))}
          </Picker>
        </View>

        {/* District Picker */}
        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={[styles.label, isFocused && styles.focusedLabel]}>
            District*
          </Text>
          <Picker
            selectedValue={formData.district}
            style={styles.input}
            onValueChange={value => {
              setFormData({...formData, district: value});
              fetchLLGs(value); // Fetch provinces based on selected region ID
            }}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}>
            <Picker.Item
              label="Select your District here"
              value=""
              style={styles.pickItem}
            />
            {Array.isArray(districts) &&
              districts.map(district => (
                <Picker.Item
                  key={district.id}
                  label={district.district_name}
                  value={district.id} // Use district ID
                  style={styles.pickItem}
                />
              ))}
          </Picker>
        </View>

        {/* LLG Picker */}
        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={[styles.label, isFocused && styles.focusedLabel]}>
            LLG*
          </Text>
          <Picker
            selectedValue={formData.LLG}
            style={styles.input}
            onValueChange={value => {
              setFormData({...formData, LLG: value});
              fetchWards(value); // Fetch wards based on selected LLG
            }}>
            <Picker.Item
              label="Select your LLG here"
              value=""
              style={styles.pickItem}
            />
            {llgs.map(llg => (
              <Picker.Item
                key={llg.id}
                label={llg.llg_name}
                value={llg.id} // Use LLG ID
                style={styles.pickItem}
              />
            ))}
          </Picker>
        </View>

        {/* Village/Ward Picker */}
        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={[styles.label, isFocused && styles.focusedLabel]}>
            Village/Ward*
          </Text>
          <Picker
            selectedValue={formData.village}
            style={styles.input}
            onValueChange={value => setFormData({...formData, village: value})}>
            <Picker.Item
              label="Select your Village/Ward here"
              value=""
              style={styles.pickItem}
            />
            {wards.map(ward => (
              <Picker.Item
                key={ward.id}
                label={ward.ward_name}
                value={ward.id} // Use ward ID
                style={styles.pickItem}
              />
            ))}
          </Picker>
        </View>

        {/* Marital Status */}
        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={[styles.label, isFocused && styles.focusedLabel]}>
            Marital Status*
          </Text>
          <Picker
            selectedValue={formData.MaritalStatus}
            style={styles.input}
            onValueChange={value =>
              setFormData({...formData, MaritalStatus: value})
            }>
            <Picker.Item
              label="Select your Marital Status here"
              value=""
              style={styles.pickItem}
            />
            <Picker.Item
              label="Single"
              value="Single"
              style={styles.pickItem}
            />
            <Picker.Item
              label="Married"
              value="Married"
              style={styles.pickItem}
            />
            <Picker.Item
              label="Divorced"
              value="Divorced"
              style={styles.pickItem}
            />
            <Picker.Item
              label="Separate"
              value="Separate"
              style={styles.pickItem}
            />
            <Picker.Item label="Other" value="Other" style={styles.pickItem} />
          </Picker>
        </View>

        {/* Dependency Children */}
        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={[styles.label, isFocused && styles.focusedLabel]}>
            How many dependends children do you have?*
          </Text>
          <Picker
            selectedValue={formData.dependetChild}
            style={styles.input}
            onValueChange={value =>
              setFormData({...formData, dependetChild: value})
            }>
            <Picker.Item label="0" value="0" style={styles.pickItem} />
            <Picker.Item label="1" value="1" style={styles.pickItem} />
            <Picker.Item label="2" value="2" style={styles.pickItem} />
            <Picker.Item label="3" value="3" style={styles.pickItem} />
            <Picker.Item label="4" value="4" style={styles.pickItem} />
            <Picker.Item label="More" value="More" style={styles.pickItem} />
          </Picker>
        </View>

        {/* Highest Qualification */}
        <View
          style={[styles.containerInput, isFocused && styles.focusedContainer]}>
          <Text style={[styles.label, isFocused && styles.focusedLabel]}>
            What is the highest qualification?*
          </Text>
          <Picker
            selectedValue={formData.highestQualification}
            style={styles.input}
            onValueChange={value =>
              setFormData({...formData, highestQualification: value})
            }>
            <Picker.Item
              label="Select your Qualification here"
              value=""
              style={styles.pickItem}
            />
            <Picker.Item label="less" value="less" style={styles.pickItem} />
            <Picker.Item label="10th" value="10th" style={styles.pickItem} />
            <Picker.Item label="12th" value="12th" style={styles.pickItem} />
            <Picker.Item
              label="Degree"
              value="Degree"
              style={styles.pickItem}
            />
            <Picker.Item
              label="Master Degree"
              value="Master Degree"
              style={styles.pickItem}
            />
            <Picker.Item label="PG" value="PG" style={styles.pickItem} />
            <Picker.Item label="Other" value="Other" style={styles.pickItem} />
          </Picker>
        </View>

        <View style={styles.inputRow}>
          <Text style={styles.heading}>Do you have bank account?</Text>
          {bankExistOptions.map(option => (
            <TouchableOpacity
              key={option.value}
              style={styles.radioContainer}
              onPress={() => setSelectedValue(option.value)}>
              <View style={styles.radioCircle}>
                {selectedValue === option.value && (
                  <View style={styles.selectedCircle} />
                )}
              </View>
              <Text style={styles.radioText}>{option.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Bank */}
        {selectedValue === 'Yes' ? (
          <View
            style={[
              styles.containerInput,
              isFocused && styles.focusedContainer,
            ]}>
            <Text style={[styles.label, isFocused && styles.focusedLabel]}>
              Which bank do you have your account?
            </Text>
            <Picker
              selectedValue={formData.bankAccount}
              style={styles.input}
              onValueChange={value =>
                setFormData({...formData, bankAccount: value})
              }>
              <Picker.Item
                label="Select your Bank here"
                value=""
                style={styles.pickItem}
              />
              <Picker.Item
                label="Kina Bank"
                value="Kina Bank"
                style={styles.pickItem}
              />
              <Picker.Item label="NDB" value="NDB" style={styles.pickItem} />
              <Picker.Item
                label="Westpac Bank"
                value="Westpac Bank"
                style={styles.pickItem}
              />
              <Picker.Item
                label="Saving & Loans"
                value="Saving & Loans"
                style={styles.pickItem}
              />
              <Picker.Item
                label="BSP Bank"
                value="BSP Bank"
                style={styles.pickItem}
              />
              <Picker.Item
                label="Micro Finance"
                value="Micro Finance"
                style={styles.pickItem}
              />
            </Picker>
          </View>
        ) : null}
        {selectedValue === 'Yes' ? (
          <View
            style={[
              styles.containerInput,
              isFocused && styles.focusedContainer,
            ]}>
            <Text style={[styles.label, isFocused && styles.focusedLabel]}>
              Which branch do you have your account?
            </Text>
            <TextInput
              style={styles.input}
              placeholder="Enter your bank & branch here"
              keyboardType="default"
              value={formData.bankBranch} // Ensure consistency in the state key
              onChangeText={text =>
                setFormData({...formData, bankBranch: text})
              } // Ensure consistency in the state key
            />
          </View>
        ) : null}
      </ScrollView>
      <View style={styles.backBg}>
        <TouchableOpacity
          // Use an anonymous function to call submitFarmerData when the button is pressed
          // onPress={() => navigation.navigate('form3PartB')}
          onPress={() => submitFarmerData(formData, navigation)}
          style={styles.savebtn}>
          <Text style={styles.savebtnText}>
            Save and Continue <Icon name="arrow-right" size={12} />
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  containerTab: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    backgroundColor: '#f7efe7',
    marginBottom: 10,
  },
  tabContainer: {
    alignItems: 'center',
    flexDirection: 'column',
  },
  circle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#ccc',
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeCircle: {
    backgroundColor: '#8a4e28', // Matches the active color in the example
  },
  tabText: {
    marginTop: 4,
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  activeText: {
    color: '#000', // Active text color
    fontWeight: 'bold',
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: '#ccc',
    marginHorizontal: 8,
    marginTop: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    color: '#8a4e28',
  },
  subtitle: {
    fontSize: 12,
    color: '#666',
    marginBottom: 16,
    color: '#2F7F6A',
  },
  field: {
    marginBottom: 16,
  },
  inputRow: {
    marginVertical: 15,
    flexDirection: 'row',
  },
  input: {
    borderRadius: 5,
    backgroundColor: '#F7F7F7',
  },
  picker: {
    fontSize: 10,
    height: 40,
    backgroundColor: '#F7F7F7',
  },
  pickItem: {
    fontSize: 14,
  },
  containerInput: {
    position: 'relative',
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginVertical: 10,
  },
  label: {
    position: 'absolute',
    top: -10,
    left: 10,
    backgroundColor: '#fff',
    paddingHorizontal: 5,
    fontSize: 12,
    color: '#ccc',
  },
  label1: {
    position: 'absolute',
    top: -15,
    left: 10,
    backgroundColor: '#fff',
    paddingHorizontal: 5,
    fontSize: 12,
    color: '#949494',
  },

  label: {
    position: 'absolute',
    top: -10,
    left: 10,
    backgroundColor: '#fff',
    paddingHorizontal: 5,
    fontSize: 12,
    color: '#949494',
  },
  focusedLabel: {
    color: '#000',
  },
  heading: {
    fontSize: 14,
    fontWeight: 'bold',
    marginRight: 10,
  },
  radioContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  radioCircle: {
    height: 15,
    width: 15,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#ccc',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 5,
  },
  selectedCircle: {
    height: 10,
    width: 10,
    borderRadius: 5,
    backgroundColor: '#ccc',
  },
  radioText: {
    fontSize: 12,
    color: '#333',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 16,
  },
  ageInput: {
    flex: 1,
    marginRight: 8,
  },
  genderGroup: {
    flexDirection: 'row',
    flex: 2,
  },
  selectedGender: {
    backgroundColor: '#8a4e28',
    color: '#fff',
  },
  uploadButton: {
    flex: 2,
    padding: 8,
    backgroundColor: '#F2F2F2',
    borderRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
  },
  photoPreview: {
    width: 40,
    height: 40,
    marginTop: 8,
    borderRadius: 20,
  },
  savebtn: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 300,
    height: 50,
    marginHorizontal: 25,
    backgroundColor: '#ecded5',
    borderRadius: 10,
  },
  savebtnText: {
    fontSize: 18,
    color: '#9d562b',
  },
});

export default FarmerForm;
