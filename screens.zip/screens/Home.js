import React,{useEffect} from 'react';
import {
	View,
	Text,
	StyleSheet,
	TouchableOpacity,
	Dimensions
} from 'react-native';
import { useNavigation } from '@react-navigation/native'; // Import useNavigation

const screenWidth = Dimensions.get("window").width;

const Dashboard = () => {
	const navigation = useNavigation(); // Get navigation object

	return (
		<View style={styles.container}>
			<Text style={styles.welcomeText}>
				Welcome <Text style={styles.name}>Mike</Text>
			</Text>
			<View style={styles.grid}>
				<TouchableOpacity  onPress={() => navigation.navigate('Products')} >
					<View style={[styles.card, styles.cocoaPrice]}>
						<Text style={styles.cardTitle}>Today's Cocoa Price</Text>
						<Text style={styles.price}>K1,639</Text>
						<Text style={styles.percentChange}>+ 6%</Text>
					</View>
				</TouchableOpacity>

				<View style={styles.card}>
					<Text style={styles.cardTitle}>Total Production</Text>
					<Text style={styles.value}>3,345 ton</Text>
					<Text style={styles.percentChangePositive}>+ 6%</Text>
				</View>

				<View style={styles.card}>
					<Text style={styles.cardTitle}>Total Revenue</Text>
					<Text style={styles.value}>K66,633</Text>
					<Text style={styles.percentChangePositive}>+ 6%</Text>
				</View>

				<View style={styles.card}>
					<Text style={styles.cardTitle}>Net Profit</Text>
					<Text style={styles.value}>K987</Text>
					<Text style={styles.percentChangeNegative}>- 2%</Text>
				</View>

				<View style={styles.card}>
					<Text style={styles.cardTitle}>Total area of farmland</Text>
					<Text style={styles.value}>5372 Acre</Text>
					<Text style={styles.percentChangePositive}>+ 6%</Text>
				</View>

				<View style={styles.card}>
					<Text style={styles.cardTitle}>Total Cocoa farmers</Text>
					<Text style={styles.value}>7,827</Text>
					<Text style={styles.percentChangeNegative}>- 1.1%</Text>
				</View>
			</View>
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "#fff",
		padding: 20,
	},
	welcomeText: {
		fontSize: 28,
		fontWeight: "bold",
		color: "#4F2E1D",
	},
	name: {
		color: "#000",
	},
	grid: {
		flexDirection: "row",
		flexWrap: "wrap",
		justifyContent: "space-between",
		marginTop: 20,
	},
	card: {
		width: screenWidth / 2 - 30,
		backgroundColor: "#F5F5F5",
		borderRadius: 8,
		padding: 15,
		marginBottom: 20,
		alignItems: "center",
	},
	cocoaPrice: {
		backgroundColor: "#BF7C4F",
	},
	cardTitle: {
		fontSize: 16,
		fontWeight: "600",
		color: "#555",
		textAlign: "center",
	},
	price: {
		fontSize: 28,
		fontWeight: "bold",
		color: "#fff",
	},
	value: {
		fontSize: 24,
		fontWeight: "bold",
		color: "#000",
	},
	percentChange: {
		marginTop: 5,
		color: "#fff",
		fontSize: 14,
		fontWeight: "bold",
	},
	percentChangePositive: {
		marginTop: 5,
		color: "#28A745",
		fontSize: 14,
		fontWeight: "bold",
	},
	percentChangeNegative: {
		marginTop: 5,
		color: "#DC3545",
		fontSize: 14,
		fontWeight: "bold",
	},
});

export default Dashboard;
