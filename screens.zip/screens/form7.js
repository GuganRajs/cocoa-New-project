import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
  ScrollView,
  Button,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Picker} from '@react-native-picker/picker';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DatePickers from '../components/utils/DatePickers';

const Form7 = () => {
  const navigation = useNavigation();
  const [formData, setFormData] = useState({
    farmer_group_name: '',
    region_id: '',
    province_id: '',
    district_id: '',
    llg_id: '',
    officially_formed: '',
    is_registered: false,
    registered_with_who: null,
    registered_on: null,
    state_of_registration: null,
    board_of_director: null,
    management_team: null,
    is_bank_account: false,
    bank_name: null,
    bank_branch: null,
  });
  const [regions, setRegions] = useState([]);
  const [provinces, setProvinces] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [llgs, setLlgs] = useState([]);
  const [wards, setWards] = useState([]);

  const entityRegisterOptions = [
    {label: 'Yes', value: true},
    {label: 'No', value: false},
  ];

  const bankAccountOptions = [
    {label: 'Yes', value: true},
    {label: 'No', value: false},
  ];

  const stateregistrationOptions = [
    {label: 'Valid', value: 'Valid'},
    {label: 'Expired', value: 'Expired'},
  ];

  const handleInputChange = ({name, value}) => {
    setFormData(prev => ({...prev, [name]: value}));
  };

  const handleSubmit = () => {
    console.log('Form Submitted:', formData);
  };

  // Fetch regions from the API
  useEffect(() => {
    fetchRegions();
  }, []);

  // Fetch Region
  const fetchRegions = async () => {
    console.log('Fetching regions...');
    try {
      const token = await AsyncStorage.getItem('access_token');
      const apiUrl = 'http://159.13.36.60:8000/api/regions/all';
      const response = await axios.get(apiUrl, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setRegions(response.data); // Populate regions with fetched data
    } catch (error) {
      console.error('Error fetching regions:', error);
    }
  };

  // Fetch provinces based on selected region ID
  const fetchProvinces = async regionId => {
    try {
      const token = await AsyncStorage.getItem('access_token');
      const apiUrl = `http://159.13.36.60:8000/api/provinces/all/${regionId}`;
      const response = await axios.get(apiUrl, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      console.log(response.data);
      setProvinces(response.data);
      setDistricts([]); // Clear districts when region/province is changed
    } catch (error) {
      console.error('Error fetching provinces:', error);
    }
  };

  // Fetch District based on selected province ID
  const fetchDistrict = async provinceId => {
    try {
      const token = await AsyncStorage.getItem('access_token');
      const apiUrl = `http://159.13.36.60:8000/api/districts/all/${provinceId}`;
      const response = await axios.get(apiUrl, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setDistricts(response.data);
      setLlgs([]);
    } catch (error) {
      console.error('Error fetching districts:', error);
    }
  };

  // Fetch LLG based on selected district ID
  const fetchLLGs = async districtId => {
    try {
      const token = await AsyncStorage.getItem('access_token');
      const apiUrl = `http://159.13.36.60:8000/api/llgs/all/${districtId}`;
      const response = await axios.get(apiUrl, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setLlgs(response.data);
      setWards([]); // Clear wards when LLG is changed
    } catch (error) {
      console.error('Error fetching LLGs:', error);
    }
  };

  // Fetch wards based on selected LLG
  const fetchWards = async llgId => {
    try {
      const token = await AsyncStorage.getItem('access_token');
      const apiUrl = `http://159.13.36.60:8000/api/wards/all/${llgId}`;
      const response = await axios.get(apiUrl, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setWards(response.data);
    } catch (error) {
      console.error('Error fetching wards:', error);
    }
  };

  //Submit form
  const submitFarmerData = async (formData, navigation) => {
    // console.log(formData.selectedGender);

    // Check if mandatory fields are filled
    if (
      !formData.farmer_group_name ||
      !formData.region_id ||
      !formData.province_id ||
      !formData.district_id ||
      !formData.llg_id ||
      !formData.officially_formed ||
      !formData.board_of_director ||
      !formData.management_team
    ) {
      alert('please fill mandatory fields');
      return; // Stop form submission
    }
    try {
      const token = await AsyncStorage.getItem('access_token'); // Retrieve token
      const apiUrl = 'http://159.13.36.60:8000/api/farmergroups'; // API endpoint
      const payload = {
        bank_branch: formData.bank_branch,
        bank_name: formData.bank_name,
        board_of_director: formData.board_of_director,
        created_at: new Date(),
        created_branch_id: '',
        created_designation_id: '',
        created_user_id: 1,
        district_id: formData.district_id,
        farmer_group_name: formData.farmer_group_name,
        is_bank_account: formData.is_bank_account,
        is_registered: formData.is_registered,
        llg_id: formData.llg_id,
        management_team: formData.management_team,
        members_and_shareholders: [
          {
            age: '',
            blocks: '',
            date: '',
            name: '',
            trees: '',
            youthOrDisabled: '',
          },
        ],
        officially_formed: formData.officially_formed,
        province_id: formData.province_id,
        region_id: formData.region_id,
        registered_on: formData.registered_on,
        registered_with_who: formData.registered_with_who,
        state_of_registration: formData.state_of_registration,
        training_details: [
          {
            capacity: '',
            date: '',
            location: '',
            targetGroup: '',
            trainer: '',
          },
        ],
        updated_at: new Date(),
        ward_id: formData.ward_id,
      };

      // console.log('Submitting farmer data:', JSON.stringify(payload, null, 2));

      // API call
      const response = await axios.post(apiUrl, payload, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      // console.log('Farmer data submitted successfully:', response.data);
      const farmerGroupId = response.data.id; // Assuming 'id' is returned in the response
      await AsyncStorage.setItem('farmerGroupId', farmerGroupId.toString());
      // alert('Farmer data submitted successfully!');
      //   navigation.goBack();
      navigation.navigate('form7_2', {data: response.data});
    } catch (error) {
      console.error('Error submitting farmer data:', error);

      const errorMessage =
        error.response?.data?.message ||
        'Failed to submit farmer data. Please try again.';
      alert(errorMessage);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>
        <Text style={{color: '#8a4e28'}}>Form 7 : </Text>Cocoa Farmer Group and
        Cooperative Profile
      </Text>

      <View style={styles.containerTab}>
        {/* Step A */}
        <View style={styles.tabContainer}>
          <TouchableOpacity style={[styles.circle, styles.activeCircle]}>
            <Icon name="check" size={12} color="#fff" />
          </TouchableOpacity>
          <Text style={[styles.tabText, styles.activeText]}>1/2</Text>
        </View>

        {/* Divider */}
        <View style={styles.line} />

        {/* Part B */}
        <View style={styles.tabContainer}>
          <TouchableOpacity style={styles.circle}>
            <Icon name="check" size={12} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.tabText}>2/2</Text>
        </View>
      </View>

      <ScrollView style={{marginBottom: 6}}>
        {/* Name Farmer Group Details */}
        <Text style={styles.sectionTitle}>Farmer Group Details</Text>
        <Text style={styles.subtitle}>
          Enter Farmer group/cooperative/business group/ILG/company details here
        </Text>

        <View style={styles.containerInput}>
          <Text style={styles.label}>
            Name of the Farmer group/cooperative/business group/ILG/company
            details here *
          </Text>
          <Text></Text>
          <Text></Text>
          <TextInput
            style={styles.input}
            placeholder="Enter name of your farmer group here"
            value={formData.farmer_group_name}
            onChangeText={text =>
              setFormData({...formData, farmer_group_name: text})
            }
          />
        </View>

        <Text style={styles.sectionTitle}>Farmer group address</Text>
        <Text style={styles.subtitle}>Enter Farmer group address here</Text>

        <View style={styles.containerInput}>
          <Text style={styles.label}>Region*</Text>
          <Picker
            selectedValue={formData.region_id}
            style={styles.input}
            onValueChange={value => {
              setFormData({...formData, region_id: value});
              fetchProvinces(value); // Fetch provinces based on selected region ID
            }}>
            <Picker.Item
              label="Select your Region here"
              value=""
              style={styles.pickItem}
            />
            {Array.isArray(regions) &&
              regions.map(region => (
                <Picker.Item
                  key={region.id}
                  label={region.region_name}
                  value={region.id}
                  style={styles.pickItem}
                />
              ))}
          </Picker>
        </View>

        <View style={styles.containerInput}>
          <Text style={styles.label}>Province*</Text>
          <Picker
            selectedValue={formData.province_id}
            style={styles.input}
            onValueChange={value => {
              setFormData({...formData, province_id: value});
              fetchDistrict(value); // Fetch provinces based on selected region ID
            }}>
            <Picker.Item
              label="Select your Province here"
              value=""
              style={styles.pickItem}
            />
            {Array.isArray(provinces) &&
              provinces.map(province => (
                <Picker.Item
                  key={province.id}
                  label={province.province_name}
                  value={province.id}
                  style={styles.pickItem}
                />
              ))}
          </Picker>
        </View>

        <View style={styles.containerInput}>
          <Text style={styles.label}>District*</Text>
          <Picker
            selectedValue={formData.district_id}
            style={styles.input}
            onValueChange={value => {
              setFormData({...formData, district_id: value});
              fetchLLGs(value); // Fetch provinces based on selected region ID
            }}>
            <Picker.Item
              label="Select your District here"
              value=""
              style={styles.pickItem}
            />
            {Array.isArray(districts) &&
              districts.map(district => (
                <Picker.Item
                  key={district.id}
                  label={district.district_name}
                  value={district.id} // Use district ID
                  style={styles.pickItem}
                />
              ))}
          </Picker>
        </View>

        <View style={styles.containerInput}>
          <Text style={styles.label}>LLG*</Text>
          <Picker
            selectedValue={formData.llg_id}
            style={styles.input}
            onValueChange={value => {
              setFormData({...formData, llg_id: value});
              fetchWards(value); // Fetch wards based on selected LLG
            }}>
            <Picker.Item
              label="Select your LLG here"
              value=""
              style={styles.pickItem}
            />
            {llgs.map(llg => (
              <Picker.Item
                key={llg.id}
                label={llg.llg_name}
                value={llg.id} // Use LLG ID
                style={styles.pickItem}
              />
            ))}
          </Picker>
        </View>

        <View style={styles.containerInput}>
          <Text style={styles.label}>Village/Ward*</Text>
          <Picker
            selectedValue={formData.ward_id}
            style={styles.input}
            onValueChange={value => setFormData({...formData, ward_id: value})}>
            <Picker.Item
              label="Select your Village/Ward here"
              value=""
              style={styles.pickItem}
            />
            {wards.map(ward => (
              <Picker.Item
                key={ward.id}
                label={ward.ward_name}
                value={ward.id} // Use ward ID
                style={styles.pickItem}
              />
            ))}
          </Picker>
        </View>

        {/*<View style={styles.containerInput}>
					<Text style={styles.label}>Marital Status*</Text>
					<Picker
						selectedValue={formData.maritalStatus}
						style={[styles.input],{backgroundColor:'#F7F7F7'}}
						onValueChange={(itemValue, itemIndex) => setFormData({ ...formData, maritalStatus: value })}
					>
						<Picker.Item label="Select your Marital Status here" value="" style={styles.pickItem}/>
						<Picker.Item label="Single" value="Single"  style={styles.pickItem}/>
						<Picker.Item label="Married" value="Married" style={styles.pickItem} />
						<Picker.Item label="Divorced" value="Divorced" style={styles.pickItem} />
						<Picker.Item label="Separate" value="Separate" style={styles.pickItem} />
					</Picker>
				</View>*/}

        <Text style={styles.sectionTitle}>Entity Details</Text>
        <Text style={styles.subtitle}>Enter entity details here</Text>

        <View style={[styles.containerInput]}>
          <DatePickers
            label="When was the entity officially formed*"
            value={formData.officially_formed}
            onChange={date =>
              setFormData({...formData, officially_formed: date.value})
            }
            // onChange={(date) => console.log(date.value)}
            placeholder="DD-MM-YYYY"
          />
        </View>

        <Text style={styles.sectionTitle}>Entity Registration Details</Text>
        <Text style={styles.subtitle}>
          Provide details about entity registration here
        </Text>

        <View style={styles.radioGroup}>
          <Text style={styles.label1}>Is the entity registered?</Text>
          {entityRegisterOptions.map(option => (
            <TouchableOpacity
              key={option.value}
              style={styles.radioContainer}
              onPress={() =>
                setFormData({...formData, is_registered: option.value})
              }>
              <View style={styles.radioCircle}>
                {formData.is_registered === option.value && (
                  <View style={styles.selectedCircle} />
                )}
              </View>
              <Text style={styles.radioText}>{option.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.containerInput}>
          <Text style={styles.label}>If yes, registered with who?</Text>
          <Picker
            selectedValue={formData.registered_with_who}
            style={([styles.input], {backgroundColor: '#F7F7F7'})}
            onValueChange={
              (itemValue, itemIndex) =>
                setFormData({...formData, registered_with_who: itemValue}) // Use itemValue here
            }>
            <Picker.Item label="Select here" value="" style={styles.pickItem} />
            <Picker.Item label="IPA" value="IPA" style={styles.pickItem} />
            <Picker.Item
              label="Co-operative Societies"
              value="Co-operative Societies"
              style={styles.pickItem}
            />
          </Picker>
        </View>

        <View style={styles.containerInput}>
          <DatePickers
            label="When was it registered?*"
            value=""
            onChange={date =>
              setFormData({...formData, registered_on: date.value})
            }
            placeholder="DD-MM-YYYY"
          />
        </View>

        <View style={styles.radioGroup}>
          <Text style={styles.label1}>Status of registration</Text>
          {stateregistrationOptions.map(option => (
            <TouchableOpacity
              key={option.value}
              style={styles.radioContainer}
              onPress={() =>
                setFormData({...formData, state_of_registration: option.value})
              }>
              <View style={styles.radioCircle}>
                {formData.state_of_registration === option.value && (
                  <View style={styles.selectedCircle} />
                )}
              </View>
              <Text style={styles.radioText}>{option.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.containerInput}>
          <Text style={styles.label}>
            Composition of current Board of Directors*
          </Text>
          <TextInput
            style={styles.textArea}
            value={formData.board_of_director}
            onChangeText={text =>
              setFormData({...formData, board_of_director: text})
            }
            placeholder="Enter here"
            placeholderTextColor="#888"
            multiline={true} // Enables multi-line input
            numberOfLines={4} // Initial number of lines to display
          />
        </View>

        <View style={styles.containerInput}>
          <Text style={styles.label}>
            Composition of current Management Team*
          </Text>
          <TextInput
            style={styles.textArea}
            value={formData.management_team}
            onChangeText={text =>
              setFormData({...formData, management_team: text})
            }
            placeholder="Enter here"
            placeholderTextColor="#888"
            multiline={true} // Enables multi-line input
            numberOfLines={4} // Initial number of lines to display
          />
        </View>

        <Text style={styles.sectionTitle}>Entity Bank Details</Text>
        <Text style={styles.subtitle}>
          Provide the bank details of the entity
        </Text>

        <View style={styles.radioGroup}>
          <Text style={styles.label1}>Do you have a bank account?</Text>
          {bankAccountOptions.map(option => (
            <TouchableOpacity
              key={option.value}
              style={styles.radioContainer}
              onPress={() =>
                setFormData({...formData, is_bank_account: option.value})
              }>
              <View style={styles.radioCircle}>
                {formData.is_bank_account === option.value && (
                  <View style={styles.selectedCircle} />
                )}
              </View>
              <Text style={styles.radioText}>{option.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.containerInput}>
          <Text style={styles.label}>Which bank do you have your account?</Text>
          <Picker
            selectedValue={formData.bank_name}
            style={([styles.input], {backgroundColor: '#F7F7F7'})}
            onValueChange={
              (itemValue, itemIndex) =>
                setFormData({...formData, bank_name: itemValue}) // Use itemValue here
            }>
            <Picker.Item label="Select here" value="" style={styles.pickItem} />
            <Picker.Item
              label="Kina Bank"
              value="Kina Bank"
              style={styles.pickItem}
            />
            <Picker.Item
              label="BSP Bank"
              value="BSP Bank"
              style={styles.pickItem}
            />
          </Picker>
        </View>

        <View style={styles.containerInput}>
          <Text style={styles.label}>
            Which branch do you have your account?
          </Text>
          <TextInput
            style={styles.input}
            placeholder="Enter branch here"
            value={formData.bank_branch}
            onChangeText={text => setFormData({...formData, bank_branch: text})}
          />
        </View>
      </ScrollView>

      <TouchableOpacity
        onPress={() => submitFarmerData(formData, navigation)}
        style={styles.savebtn}>
        <Text style={styles.savebtnText}>
          Sava and Continue <Icon name="arrow-right" size={12} />
        </Text>
      </TouchableOpacity>
      {/*<TouchableOpacity onPress={() => navigation.navigate('form7_2')}  style={styles.savebtn}>
				<Text style={styles.savebtnText}>Sava and Continue <Icon name="arrow-right" size={12}/></Text>
			</TouchableOpacity>*/}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  containerTab: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    backgroundColor: '#f7efe7',
    marginBottom: 10,
  },
  tabContainer: {
    alignItems: 'center',
    flexDirection: 'column',
  },
  circle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#ccc',
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeCircle: {
    backgroundColor: '#8a4e28', // Matches the active color in the example
  },

  completeCircle: {
    backgroundColor: '#02A552',
  },
  tabText: {
    marginTop: 4,
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  activeText: {
    color: '#000', // Active text color
    fontWeight: 'bold',
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: '#ccc',
    marginHorizontal: 8,
    marginTop: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    color: '#8a4e28',
  },
  subtitle: {
    fontSize: 12,
    color: '#666',
    marginBottom: 16,
    color: '#2F7F6A',
  },
  containerInput: {
    position: 'relative',
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginVertical: 10,
  },
  label: {
    position: 'absolute',
    top: -2,
    zIndex: 1,
    left: 10,
    backgroundColor: '#fff',
    paddingHorizontal: 5,
    fontSize: 12,
    color: '#949494',
  },
  label1: {
    position: 'absolute',
    top: -10,
    left: 10,
    backgroundColor: '#fff',
    paddingHorizontal: 5,
    fontSize: 12,
    color: '#949494',
  },
  input: {
    borderRadius: 5,
    backgroundColor: '#F7F7F7',
  },
  textArea: {
    width: '100%',
    height: 70,
    borderRadius: 8,
    padding: 10,
    textAlignVertical: 'top',
    backgroundColor: '#F7F7F7',
  },
  pickItem: {
    fontSize: 14,
  },
  heading: {
    fontSize: 14,
    fontWeight: 'bold',
    marginRight: 10,
  },
  radioGroup: {
    flexDirection: 'row',
    flex: 1,
  },
  radioContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: 10,
  },
  radioCircle: {
    height: 15,
    width: 15,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#ccc',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 5,
  },
  selectedCircle: {
    height: 10,
    width: 10,
    borderRadius: 5,
    backgroundColor: '#ccc',
  },
  radioText: {
    fontSize: 12,
    color: '#333',
  },
  savebtn: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 300,
    height: 50,
    marginHorizontal: 25,
    backgroundColor: '#F7F7F7',
    borderRadius: 10,
  },
  savebtnText: {
    fontSize: 18,
  },
});

export default Form7;
