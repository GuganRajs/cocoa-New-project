import React, {Component} from 'react';
import {
	View,
	Text,
	StyleSheet,
	ScrollView,
	Image,
	TextInput,
	TouchableOpacity,
	Dimensions,
	Alert,
} from 'react-native';
import {connect} from 'react-redux';
import {loggedIn} from '../redux/reducer';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LinearGradient from 'react-native-linear-gradient';
import {NavigationActions} from 'react-navigation';  // Add this for navigation

const {width, height} = Dimensions.get('window'); // Get screen dimensions

const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
	subContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		marginTop: 40,
	},
	inputView: {
		width: '100%',
		alignItems: 'center',
	},
	SectionStyle: {
		flexDirection: 'row',
		alignItems: 'center',
		backgroundColor: 'white',
		borderRadius: 15,
		borderWidth: 1,
		borderColor: '#ccc',
		paddingHorizontal: 5,
		marginVertical: 10,
		width: width * 0.8,
	},
	inputStyle: {
		flex: 1,
		fontSize: 16,
		color: 'black',
		paddingVertical: 10,
	},
	appName: {
		fontSize: 24,
		fontWeight: '500',
		textAlign: 'center',
		color: 'black',
	},
	appNameSub: {
		fontSize: 24,
		fontWeight: '300',
		marginBottom: 20,
		textAlign: 'center',
		color: 'black',
	},
	username: {
		fontSize: 16,
		fontWeight: '300',
		marginBottom: 5,
		alignSelf: 'flex-start',
		color: '#000000',
		marginLeft: width * 0.1,
		marginTop: height * 0.1
	},
	passwd: {
		fontSize: 16,
		fontWeight: 'normal',
		marginTop: 10,
		alignSelf: 'flex-start',
		color: '#000000',
		marginLeft: width * 0.1,
	},
	textCont: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		width: width * 0.8,
		marginTop: 20,
		justifyContent: "center"
	},
	btn: {
		height: 48,
		width: width * 0.8,
		backgroundColor: '#9D562B',
		alignItems: 'center',
		justifyContent: 'center',
		marginTop: 20,
		borderRadius: 15,
	},
	iconStyle: {
		width: 24,
		height: 24,
		tintColor: '#9D562B',
		marginRight: 10,
	},
	backgroundImage: {
		// position: 'absolute',
		bottom: 0,
		left: 0,
		width: width,
		height: height * 0.25,
		resizeMode: 'contain',
	},
});

const setLoginLocal = async loginData => {
	try {
		await AsyncStorage.setItem('loginData', JSON.stringify(loginData));
	} catch (err) {}
};

export class Login extends Component {
	constructor(props) {
		super(props);
		this.state = {
			email: '',
			password: '',
			isPasswordVisible: false, // State to toggle password visibility
			isLoading: false, // Loading state for login process
		};
	}

	togglePasswordVisibility = () => {
		this.setState(prevState => ({
			isPasswordVisible: !prevState.isPasswordVisible,
		}));
	};

	// Function to validate email and password
	validateInput = () => {
		const {email, password} = this.state;
		if (!email || !password) {
			Alert.alert('Error', 'Please fill in both fields.');
			return false;
		}
		// Basic email validation
		const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
		if (!emailRegex.test(email)) {
			Alert.alert('Error', 'Please enter a valid email address.');
			return false;
		}
		return true;
	};

	handleLogin = async () => {
	console.log("Checking login...");
	const { email, password } = this.state;

	if (!email || !password) {
		Alert.alert(
			"Login Error",
			"Please fill all the details",
			[{ text: "OK" }]
		);
		return;
	}

	this.setState({ isLoading: true, isEditable: false });

	try {
		const response = await fetch('http://159.13.36.60:8000/api/login', {
			method: 'POST', // POST request
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({
				email: email,
				password: password,
			}),
		});

		const data = await response.json(); // Parse JSON response

		console.log('API Response:', data);

		if (response.ok) {
			// Save access token in AsyncStorage
			await AsyncStorage.setItem('access_token', data.access_token);

			console.log("Login Successful");
			console.log(data.access_token);
			Alert.alert("Success", "Logged in successfully");
			// Navigate to the next screen or update app state here
			this.props.loggedIn(data);
		} else {
			Alert.alert(
				"Login Error",
				"Invalid credentials. Please try again.",
				[{ text: "OK" }]
			);
		}
	} catch (error) {
		console.error("Error during login:", error);
		Alert.alert("Error", "Something went wrong. Please try again later.");
	} finally {
		this.setState({ isLoading: false, isEditable: true });
	}
};

	
	
	render() {
		return (
			<LinearGradient
				style={{flex: 1}}
				colors={['#FFDC99', '#FFD496', '#FFD395', '#FFD395']}>
				<ScrollView style={styles.container}>
					<View style={styles.subContainer}>
						<Image
							source={require('../assets/logo.jpeg')}
							style={{
								height: 100,
								resizeMode: 'contain',
								alignSelf: 'center',
								width: 250,
							}}
						/>
						<Text style={styles.appName}>Cocoa Board of</Text>
						<Text style={styles.appNameSub}>Papua New Guinea</Text>

						<Text style={styles.username}>User name/email</Text>
						<View style={styles.SectionStyle}>
							<TextInput
								style={styles.inputStyle}
								placeholderTextColor="#B8B8B8"
								placeholder="Enter Text here"
								value={this.state.email}
								onChangeText={email => this.setState({email})}
								keyboardType="email-address"
								blurOnSubmit={false}
							/>
							<Image
								source={require('../assets/user_icon.png')}
								style={styles.iconStyle}
							/>
						</View>

						<Text style={styles.passwd}>Password</Text>
						<View style={styles.SectionStyle}>
							<TextInput
								style={styles.inputStyle}
								placeholderTextColor="#B8B8B8"
								placeholder="Enter your password here"
								secureTextEntry={!this.state.isPasswordVisible}
								value={this.state.password}
								onChangeText={password => this.setState({password})}
								blurOnSubmit={false}
							/>
							<TouchableOpacity onPress={this.togglePasswordVisibility}>
								<Image
									source={
										this.state.isPasswordVisible
											? require('../assets/eye_off.png') // Use an appropriate "eye open" icon
											: require('../assets/eye_off.png') // Use an appropriate "eye closed" icon
									}
									style={styles.iconStyle}
								/>
							</TouchableOpacity>
						</View>

						<TouchableOpacity
							style={styles.btn}
							onPress={this.handleLogin}
							disabled={this.state.isLoading}>
							<Text style={{fontSize: 18, fontWeight: 'bold', color: '#ffffff'}}>
								{this.state.isLoading ? 'Logging in...' : 'Login →'}
							</Text>
						</TouchableOpacity>

						<View style={styles.textCont}>
							<Text style={{color: 'black'}}>Forgot Password</Text>
							{/* <Text style={{color: 'black'}}>Create Account</Text> */}
						</View>
					</View>
					<View>
						<Image
							source={require('../assets/flower.png')} // Cocoa flower image as background
							style={styles.backgroundImage}
						/>
					</View>
				</ScrollView>
			</LinearGradient>
		);
	}
}

export default connect(null, {loggedIn})(Login);
